requirejs(['common'],function(c){
    requirejs(['jquery','validata','style'],function ($,validata) {
        var api = validata.isApi();
        var code = validata.getQueryString("code");
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        if(code){
            var current_url = sessionStorage.getItem('current_url');
            $.ajax({
                async: false,
                url: api+'?code='+code,
                type: "get",
                //下面几行是jsoup，如果去掉下面几行的注释，后端对应的返回结果也要去掉注释
                dataType: 'json',
                data: {
                    key:key,
                    module:'member',
                    method:'wechat.get_user',
                    request_mode:'get',
                    sign:sign,
                    timestamp:timestamp
                },
                success: function (h) {
                    if(h.status =='success'){
                        var uid = h.result.uid;
                        var openid = h.result.openid;
                        sessionStorage.setItem('uid',uid);
                        sessionStorage.setItem('openid',openid);
                        window.location.href=current_url;
                    }
                }
            });
        }
    })
})
