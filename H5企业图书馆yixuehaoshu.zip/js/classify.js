requirejs(['common'],function(c){
    requirejs(['jquery','validata','jqclassify','cartshow','style'],function ($,validata) {
        var api = validata.isApi();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        $.ajax({
            type: 'get',
            url: api,
            data:{
                key:key,
                module:'market',
                method:'category',
                request_mode:'get',
                page:'1',
                sign:sign,
                timestamp:timestamp
            },
            dataType: 'json',
            success: function (a) {
                //console.log(a);
                if(a.status =='success') {
                    var obj = a.result;
                    var classifylist = '';
                    var classifyinfo = '';
                    for (var i in obj) {
                        classifylist +='<li data_main="'+i+'"><a href="javascript:;">'+obj[i].name+'</a></li>';
                        var objs = obj[i].children;
                        for(var j in objs){
                            var objn = objs[j].children;
                            var classif = '';
                            var carr = [];
                            for(var n in objn){
                                carr.push(objn[n]);
                            }
                            if(carr.length>1){
                                for(var n in objn){
                                    classif += '<div class="classify_three"><a href="classify_details.html?cid='+objn[n].id+'">└─'+objn[n].name+'</a></div>'
                                }
                            }
                            classifyinfo +='<div class="tab-content '+i+'"><a href="classify_details.html?cid='+objs[j].id+'"><h4>'+objs[j].name+'<b>ALL>></b></h4></a>'+classif+'</div>';
                        }
                    }
                    $('.tabs .tabs-list').append(classifylist);
                    $('.tabs .tabs-container').append(classifyinfo);
                    $('.tabs .tabs-list').find('li').eq(0).addClass('active');
                    var data_main = $('.tabs .tabs-list').find('li').eq(0).attr('data_main');
                    $('.tab-content').hide();
                    $('.'+data_main).show();
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
        $(document).on('click','.tabs-list li',function () {
            $('.tabs-list li').removeClass('active');
            $(this).addClass('active');
            var data_main = $(this).attr('data_main');
            $('.tab-content').hide();
            $('.'+data_main).show();
        });
    })
});