var uid = sessionStorage.getItem('uid');
//判断是否微信环境
if(!uid || uid == ''){
    var ua = window.navigator.userAgent.toLowerCase();
    if(ua.match(/MicroMessenger/i) == 'micromessenger' || ua.match(/_SQ_/i) == '_sq_'){
        var current_url = window.location.href;
        sessionStorage.setItem('current_url',current_url);
        window.location.href='https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx1048afd03302531b&redirect_uri=http%3a%2f%2fm.yixuehaoshu.com%2fjump.html&response_type=code&scope=snsapi_userinfo&state='+location.search+'&connect_redirect=1#wechat_redirect';
        //微信号登录
    }
}
