requirejs(['common'],function(c){
    requirejs(['jquery','validata'],function ($,validata) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var openid = validata.isOpenid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var referee = validata.getQueryString('referee');
        var timestamp = validata.signCont().timestamp;
        var is_subscribe = sessionStorage.getItem('issubscribe');
        var issubscribe;
        //是否是推荐的
        if(referee && referee!=''){
            var refereeid = window.atob(referee);
            if(uid != refereeid){
                $.ajax({
                    type: 'post',
                    url: api,
                    data:{
                        key:key,
                        module:'member',
                        method:'user.store_referee_relation',
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid,
                        referee:refereeid
                    },
                    dataType: 'json',
                    success: function (a) {
                        if(a.status =='success') {

                        }
                    }
                });
            }
        }
        if(!is_subscribe){
            if(openid){
                $.ajax({
                    type: 'get',
                    url: api,
                    async:true,
                    data:{
                        module:'member',
                        method:'wechat.user.'+openid,
                        request_mode:'get',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    },
                    dataType: 'json',
                    success: function (a) {
                        console.log(a);
                        if(a.status =='success') {
                            issubscribe = a.result.subscribe;
                            if(issubscribe == 1){
                                sessionStorage.setItem('issubscribe',issubscribe);
                                $('.notFollow').hide();
                                $('.search').css('margin-top','0');
                                $('.classify').css('margin-top','0');
                                $('.shopping').css('margin-top','0');
                                $('.order_nav').css('margin-top','0');
                                $('.order_list').css('margin-top','53px');
                                $('.mine').css('margin-top','0');
                                $('.order_state').css('margin-top','0');
                                $('.order_address').css('margin-top','0');
                                $('.classify_details_menu').css('margin-top','0');
                                $('.classify_details .tabs-container').css('padding-top','120px');
                                $('.product_details').css('margin-top','0');
                                $('.address').css('margin-top','0');
                                $('.add_address').css('margin-top','0');
                            }else{
                                $('.notFollow').css('display','flex');
                                $('.search').css('margin-top','56');
                                $('.classify').css('margin-top','56');
                                $('.shopping').css('margin-top','56');
                                $('.order_nav').css('margin-top','56');
                                $('.order_list').css('margin-top','109');
                                $('.mine').css('margin-top','56');
                                $('.order_state').css('margin-top','56');
                                $('.order_address').css('margin-top','56');
                                $('.classify_details_menu').css('margin-top','56');
                                $('.classify_details .tabs-container').css('padding-top','176px');
                                $('.product_details').css('margin-top','56');
                                $('.address').css('margin-top','56');
                                $('.add_address').css('margin-top','56');
                            }
                        }else{

                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }
                });
            }
		}else{
            $('.notFollow').hide();
            $('.search').css('margin-top','0');
            $('.classify').css('margin-top','0');
            $('.shopping').css('margin-top','0');
            $('.order_nav').css('margin-top','0');
            $('.order_list').css('margin-top','53px');
            $('.mine').css('margin-top','0');
            $('.order_state').css('margin-top','0');
            $('.order_address').css('margin-top','0');
            $('.classify_details_menu').css('margin-top','0');
            $('.classify_details .tabs-container').css('padding-top','120px');
            $('.product_details').css('margin-top','0');
            $('.address').css('margin-top','0');
            $('.add_address').css('margin-top','0');
		}

// 未关注点击弹出框
// 点击未关注区域 
	$(".notFollow").click(function(){
		// 弹出这个弹出框
		$(".Popup").show();
		// 吉祥物突出来的高度
		var PopupConTopHeight = $(".PopupConTop img").height();
		$(".PopupConTop img").css("margin-top",-PopupConTopHeight/2 - 10);
		// 白色部分  的高度要加上吉祥物突出来的高度
		$(".PopupConCon").css("margin-top",PopupConTopHeight/2 +10);
	});

	// 点击×关闭这个弹出框
	$("#ClosePopup").click(function(){
		$(".Popup").hide();
	});

	// 点击联系供货商
	$(".contact_seller").click(function(){
		// 弹出这个弹出框
		$(".seller_contact").show();
		// 吉祥物突出来的高度
		var sellerHeight = $(".seller_contact_top img").height();
		$(".seller_contact_top img").css("margin-top",-sellerHeight/2 - 10);
		// 白色部分  的高度要加上吉祥物突出来的高度
		$(".seller_contact_con_con").css("margin-top",sellerHeight/2 +10);
	});
	// 购物车点击删除
	$(".delete").click(function(){
		// 弹出这个弹出框
		$(".seller_contact2").show();
		// 吉祥物突出来的高度
		var sellerHeight = $(".seller_contact_top img").height();
		$(".seller_contact_top img").css("margin-top",-sellerHeight/2 - 10);
		// 白色部分  的高度要加上吉祥物突出来的高度
		$(".seller_contact_con_con").css("margin-top",sellerHeight/2 +10);
	});
	// 点击×关闭这个弹出框
	$(".seller_contact_close").click(function(){
		$(".seller_contact").hide();
		$(".seller_contact2").hide();
        $(".seller_contact3").hide();
        $(".seller_contact4").hide();
        $(".seller_contact5").hide();
	});

	// 购物车点击关闭
	$(".seller_delete").click(function(){
		$(".seller_contact2").hide();
        $(".seller_contact3").hide();
        $(".seller_contact4").hide();
        $(".seller_contact5").hide();
	});

	// 点击商品详情  选择属性弹出框
	$(".subnav .subnav_right a").click(function(){
		// 弹出这个弹出框
		$(".attribute").show();
		// 吉祥物突出来的高度
		var attributeHeight = $(".attribute_contact_top img").height();
		$(".attribute_contact_top img").css("margin-top",-attributeHeight/2 - 10);
		// 白色部分  的高度要加上吉祥物突出来的高度
		$(".attribute_contact_con_con").css("margin-top",attributeHeight/2 +10);
	});


	// 点击×关闭这个弹出框
	$("attribute_contact_close").click(function(){
		$("attribute").hide();
	});

	// 购物车点击关闭
	$(".attribute_delete").click(function(){
		$(".attribute").hide();
	});

	// 滚动页面时  搜索框显示在顶部
	$(window).scroll(function() {
	    var notFollowcss = $('.notFollow').css('display');
		if($(window).scrollTop()>=0.1){
            if(is_subscribe == 1){
                $(".classify_details .zhiding").css("top",'0');
                $(".search").css({"box-shadow":"3px 3px 7px rgba(0,0,0,0.15)",'position':'fixed',"margin-top":0});
            }else{
                if(notFollowcss =='flex'){
                    $(".search").css({"box-shadow":"3px 3px 7px rgba(0,0,0,0.15)",'position':'fixed',"margin-top":56});
                    $(".classify_details .zhiding").css("top",'0');
                    $(".classify_details .tabs-container").css("padding-top",176);
                    $(".order_list").css("margin-top",109);
                    $(".classify_details_menu").css("margin-top","56");
                }else{
                    $(".classify_details .zhiding").css("top",'0');
                    $(".search").css({"box-shadow":"3px 3px 7px rgba(0,0,0,0.15)",'position':'fixed',"margin-top":0});
                }
            }
		}else{
            if(is_subscribe == 1){
                $(".search").css({'box-shadow':'none','position':'relative',"margin-top":0});
                $(".classify_details .zhiding").css("top",'0');
            }else{
                if(notFollowcss =='flex'){
                    $(".search").css({'box-shadow':'none','position':'relative',"margin-top":56});
                    $(".classify_details .zhiding").css("top",0);
                    $(".classify_details .tabs-container").css("padding-top",176);
                    $(".order_list").css("margin-top",109);
                    $(".classify_details_menu").css("margin-top","56");
                }else{
                    $(".search").css({'box-shadow':'none','position':'relative',"margin-top":0});
                    $(".classify_details .zhiding").css("top",'0');
                }
            }
		}
	});
	$(window).scrollTop(0);

	// 分类页面  图片的高度
	var classifyWidth = $(".classify .tabs-container .tab-content .classify_three a").width();
		$(".classify .tabs-container .tab-content .classify_three a").css("height",classifyWidth);

	// 比价页面 图书显示为正方形的
	// 商品详情页面的轮播图
	$(".product_details").height($(".product_details").width());
	//产品详情页面，添加购物车
	$('.choice_attribute').find('button').eq(0).click(function () {
		var oldValue=parseInt($(this).parent('div').find('input').val());
		oldValue-- ;
		if(oldValue<0){
			oldValue = 0;
		}
		$(this).parent('div').find('input').val(oldValue);
	});
	$('.choice_attribute').find('button').eq(1).click(function () {
		var oldValue=parseInt($(this).parent('div').find('input').val());
		oldValue++;
		$(this).parent('div').find('input').val(oldValue);
	});

	// 添加地址页面 输入框的宽度
	$(".fill_in input").width($(".fill_in").width() - $(".fill_in span").width());
	$(".fill_in textarea").width($(".fill_in").width() - $(".fill_in span").width());
	$(".fill_in .choice_address").width($(".fill_in").width() - $(".fill_in span").width());
	$(".fill_in .fill_code input").width($(".fill_in").width() - $(".fill_in span").width() - $(".fill_in .fill_code button").width() -10);

	// 选择性别
	$(".sexsex").click(function(){
		$(".choice_sex").show();
	});
	$("#Close_sex").click(function(){
		$(".choice_sex").hide();
	});
	$(".sex .man").click(function(){
		$(".choice_sex").hide();
		var sextext = $(this).children("span").text();
		$(".sexsex").children("font").text(sextext);
	});

    })
});
