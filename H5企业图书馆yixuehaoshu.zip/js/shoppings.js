requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','style','shopping'],function ($,validata,template) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        //记录状态
        var state=true;
        $.ajax({
            type: 'get',
            url: api,
            data:{
                module:'order',
                method:'cart.show',
                request_mode:'get',
                key:key,
                sign:sign,
                timestamp:timestamp,
                uid:uid
            },
            dataType: 'json',
            success: function (r) {
                console.log(r);
                if(r.status =='success') {
                    $('.no_more').attr('num',r.pageTotal);
                    $('.no_more').attr('now','1');
                    var orderinfo = r.result;
                    if(orderinfo == null){
                        $('.zanwu').css('display','flex');
                        $('.no_more').hide();
                        $('.shopping').hide();
                        $('.total_price').hide();
                        $('.pay_bot a').eq(1).hide();
                    }else{
                        var html = template('tpl_translation_shopping_list', orderinfo);
                        document.getElementById('translation_shopping_list').innerHTML = html;
                        $('#translation_shopping_list .shop-group-item .single_shop .shop-info .delete').on('click',function () {
                            $('.seller_contact2').show();
                            var cart_id = $(this).parents('li').attr('cart_id');
                            $('.seller_contact2').attr('ca_id',cart_id);
                        });
                        if(r.pageTotal==1){
                            $('.no_more').find('p').text('咩有了~');
                            state=false;
                        }
                    }

                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
        window.addEventListener("beforeunload", function(e) {
            $('#AllCheck').attr('checked',false)
        });
        $('.seller_contact2 .seller_contact_button a').eq(0).on('click',function () {
            var ca_id = $(this).parents('.seller_contact2').attr('ca_id');
            $.ajax({
                type: 'post',
                url: api,
                data:{
                    cart_id:ca_id,
                    module:'order',
                    method:'cart.delete',
                    request_mode:'post',
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    uid:uid
                },
                dataType: 'json',
                success: function (r) {
                    console.log(r);
                    if(r.status =='success') {
                        $('.seller_contact2').hide();
                        $('#'+ca_id).remove();
                    }else{
                        alert(r.msg);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $(document).on('click','.minus',function () {
            var cart_id = $(this).parents('li').attr('cart_id');
            var market_id = $(this).parents('li').attr('market_id');
            var number = $(this).parent('.shop-arithmetic').find('.num').text();
            $.ajax({
                type: 'post',
                url: api,
                data:{
                    cart_id:cart_id,
                    market_id:market_id,
                    module:'order',
                    method:'cart.update',
                    request_mode:'post',
                    number:number,
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    uid:uid
                },
                dataType: 'json',
                success: function (r) {
                    console.log(r);
                    if(r.status =='success') {

                    }else{
                        alert(r.msg);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $(document).on('click','.plus',function () {
            var plus_this = $(this);
            var cart_id = plus_this.parents('li').attr('cart_id');
            var market_id = plus_this.parents('li').attr('market_id');
            var number = plus_this.parent('.shop-arithmetic').find('.num').text();
            $.ajax({
                type: 'post',
                url: api,
                data:{
                    cart_id:cart_id,
                    market_id:market_id,
                    module:'order',
                    method:'cart.update',
                    request_mode:'post',
                    number:number,
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    uid:uid
                },
                dataType: 'json',
                success: function (r) {
                    console.log(r);
                    if(r.status =='success') {

                    }else{
                        plus_this.parent('.shop-arithmetic').find('.num').text(number-1)
                        alert(r.msg);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.pay_btn').on('click',function () {
            var cart_ids = [];
            // var cart_id = $('.shopping ul li').attr('cart_id');
           $('.single_shop').each(function () {
               $(this).find(".goodsCheck").each(function() { //循环店铺里面的商品
                   if ($(this).is(":checked")) { //如果该商品被选中
                       var cart_id = $(this).parents("li").attr('cart_id');
                       cart_ids.push(cart_id);
                   }
               });
           });
           if(cart_ids.length <1){
               alert('没有选中商品');
               return false;
           }
           window.location.href= 'order_generate.html?cart_ids='+cart_ids;
        });
        //滚动条滚动的时候
        $(window).scroll(function(){
            //获取当前加载更多按钮距离顶部的距离
            var bottomsubmit = $('.no_more').offset().top;
            //获取当前页面底部距离顶部的高度距离
            var nowtop = $(document).scrollTop()+$(window).height();
            //获取当前页数，默认第一页
            var now = $('.no_more').attr('now');
            //获取总页数，PHP分页的总页数
            var num = $('.no_more').attr('num');
            //当当前页面的高度大于按钮的高度的时候开始触发加载更多数据
            if(nowtop>bottomsubmit){
                //如果为真继续执行，这个是用于防止滚动获取过多的数据情况
                if(state==true){
                    //执行一次获取数据并停止再进来获取数据
                    state=false;
                    setTimeout(function(){
                        //当前页数++
                        now++;
                        //记录当前为第二页
                        $('.no_more').attr('now',now);
                        var nnow = $('.no_more').attr('now');
                        $.ajax({
                            //通过ajax传页数参数获取当前页数的数据
                            url:api+'?page='+nnow,
                            type:'get',
                            async:true,
                            cache:false,
                            data:{
                                module:'order',
                                method:'cart.show',
                                request_mode:'get',
                                key:key,
                                sign:sign,
                                timestamp:timestamp,
                                uid:uid
                            },
                            dataType:"json",
                            success:function(data){
                                //console.log(data);
                                //把通过php处理的html和数据，写入容器底部
                                var orderinfo = data.result;
                                var html = template('tpl_translation_shopping_list', orderinfo);
                                $('#translation_shopping_list').append(html);
                                // document.getElementById('translation_classify_list').innerHTML = html;
                                //如果当前页大于等于总页数就提示没有更多数据
                                if(now>=num){
                                    $('.no_more').find('p').text('咩有了~');
                                    //并把状态设置为假，下次下滑滚动时不再通过ajax获取数据
                                    state=false;
                                }else{
                                    // 否则继续
                                    state=true;
                                }
                            },
                            error:function(XMLHttpRequest, textStatus, errorThrown){
                                $('.no_more').find('p').text('加载错误,请刷新页面！');
                            }
                        });
                    },500);
                }
            }
        });
    })
});