requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','cartshow','style'],function ($,validata,template) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var openid = validata.isOpenid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        $(document).on('click','.delete_order',function () {
            var order_id = $(this).attr('order_id');
            $('.seller_contact4').attr('o_id',order_id);
            $('.seller_contact4').show();
        });
        $(document).on('click','.confirm_order',function () {
            var order_id = $(this).attr('order_id');
            $('.seller_contact5').attr('o_id',order_id);
            $('.seller_contact5').show();
        });
        $('.seller_contact5 .seller_contact_button a').eq(1).on('click',function () {
            var o_id = $('.seller_contact5').attr('o_id');
            $.ajax({
                url: api,
                type: 'post',
                data: {
                    key: key,
                    sign: sign,
                    timestamp: timestamp,
                    method: 'order.confirm',
                    module: 'order',
                    request_mode: 'post',
                    order_id:o_id,
                    uid:uid
                },
                dataType: 'json',
                success: function (b) {
                    if(b.status=='success'){
                        $('#'+o_id).remove();
                        $('.seller_contact5').hide();
                    }else{
                        alert('操作失败');
                    }
                }
            })
        });
        $('.seller_contact4 .seller_contact_button a').eq(0).on('click',function () {
            var o_id =  $('.seller_contact4').attr('o_id');
            $.ajax({
                type: 'post',
                url: api,
                data:{
                    order_id:o_id,
                    key:key,
                    module:'order',
                    method:'order.cancel',
                    request_mode:'post',
                    sign:sign,
                    timestamp:timestamp,
                    uid:uid,
                    user_type:'2'
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                       $('#'+o_id).remove();
                        $('.seller_contact4').hide();
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        //记录状态
        var state=true;
        var orderdata;
        orderdata={
            key:key,
            module:'order',
            method:'order.get_all',
            request_mode:'get',
            sign:sign,
            timestamp:timestamp,
            uid:uid,
            user_type:'2'
        };
        $.ajax({
            type: 'get',
            url: api+'?page='+1,
            async:false,
            data:orderdata,
            dataType: 'json',
            success: function (a) {
                console.log(a);
                if(a.status =='success') {
                    var orderinfo = a.result;
                    if(orderinfo == ''){
                        $('.no_more').hide();
                        $('.zanwu').css('display','flex');
                    }else{
                        $('.no_more').show();
                        $('.zanwu').css('display','none');
                        $('.no_more').attr('num',a.pageTotal);
                        $('.no_more').attr('now','1');
                        var html = template('tpl_translation_order_list', orderinfo);
                        document.getElementById('translation_order_list').innerHTML = html;
                        if(a.pageTotal==1){
                            $('.no_more').find('p').text('咩有了~');
                            state=false;
                        }
                    }
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
        $('.order_nav a').on('click',function () {
            document.body.scrollTop = 0;
            $('.order_nav a').removeClass('active');
            $(this).addClass('active');
            $('#translation_order_list').html('');
            $('.no_more').find('p').text('上拉加载更多');
            state=true;
        });
        $('.order_nav a').eq(0).on('click',function () {
            orderdata={
                key:key,
                module:'order',
                method:'order.get_all',
                request_mode:'get',
                sign:sign,
                timestamp:timestamp,
                uid:uid,
                user_type:'2'
            }
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:orderdata,
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        var orderinfo = a.result;
                        if(orderinfo == ''){
                            $('.no_more').hide();
                            $('.zanwu').css('display','flex');
                        }else{
                            $('.no_more').show();
                            $('.zanwu').css('display','none');
                            $('.no_more').attr('num',a.pageTotal);
                            $('.no_more').attr('now','1');
                            var html = template('tpl_translation_order_list', orderinfo);
                            document.getElementById('translation_order_list').innerHTML = html;
                            prices();
                            if(a.pageTotal==1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.order_nav a').eq(1).on('click',function () {
            orderdata = {
                key:key,
                module:'order',
                method:'order.get_all',
                request_mode:'get',
                sign:sign,
                timestamp:timestamp,
                uid:uid,
                user_type:'2',
                status:'1'
            }
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:orderdata,
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        var orderinfo = a.result;
                        if(orderinfo == ''){
                            $('.no_more').hide();
                            $('.zanwu').css('display','flex');
                        }else{
                            $('.no_more').show();
                            $('.zanwu').css('display','none');
                            $('.no_more').attr('num',a.pageTotal);
                            $('.no_more').attr('now','1');
                            var html = template('tpl_translation_order_list', orderinfo);
                            document.getElementById('translation_order_list').innerHTML = html;
                            prices();
                            if(a.pageTotal==1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.order_nav a').eq(2).on('click',function () {
            orderdata = {
                key:key,
                module:'order',
                method:'order.get_all',
                request_mode:'get',
                sign:sign,
                timestamp:timestamp,
                uid:uid,
                user_type:'2',
                status:'2'
            }
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:orderdata,
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        var orderinfo = a.result;
                        if(orderinfo == ''){
                            $('.no_more').hide();
                            $('.zanwu').css('display','flex');
                        }else{
                            $('.no_more').show();
                            $('.zanwu').css('display','none');
                            $('.no_more').attr('num',a.pageTotal);
                            $('.no_more').attr('now','1');
                            var html = template('tpl_translation_order_list', orderinfo);
                            document.getElementById('translation_order_list').innerHTML = html;
                            prices();
                            if(a.pageTotal==1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.order_nav a').eq(3).on('click',function () {
            orderdata = {
                key:key,
                module:'order',
                method:'order.get_all',
                request_mode:'get',
                sign:sign,
                timestamp:timestamp,
                uid:uid,
                user_type:'2',
                status:'3'
            }
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:orderdata,
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        var orderinfo = a.result;
                        if(orderinfo == ''){
                            $('.no_more').hide();
                            $('.zanwu').css('display','flex');
                        }else{
                            $('.no_more').show();
                            $('.zanwu').css('display','none');
                            $('.no_more').attr('num',a.pageTotal);
                            $('.no_more').attr('now','1');
                            var html = template('tpl_translation_order_list', orderinfo);
                            document.getElementById('translation_order_list').innerHTML = html;
                            prices();
                            if(a.pageTotal==1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.order_nav a').eq(4).on('click',function () {
            orderdata ={
                key:key,
                module:'order',
                method:'order.get_all',
                request_mode:'get',
                sign:sign,
                timestamp:timestamp,
                uid:uid,
                user_type:'2',
                status:'4'
            }
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:orderdata,
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        var orderinfo = a.result;
                        if(orderinfo == ''){
                            $('.no_more').hide();
                            $('.zanwu').css('display','flex');
                        }else{
                            $('.no_more').show();
                            $('.zanwu').css('display','none');
                            $('.no_more').attr('num',a.pageTotal);
                            $('.no_more').attr('now','1');
                            var html = template('tpl_translation_order_list', orderinfo);
                            document.getElementById('translation_order_list').innerHTML = html;
                            prices();
                            if(a.pageTotal==1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.order_nav a').eq(5).on('click',function () {
            orderdata ={
                key:key,
                module:'order',
                method:'order.get_all',
                request_mode:'get',
                sign:sign,
                timestamp:timestamp,
                uid:uid,
                user_type:'2',
                status:'5,6'
            }
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:orderdata,
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        var orderinfo = a.result;
                        if(orderinfo == ''){
                            $('.no_more').hide();
                            $('.zanwu').css('display','flex');
                        }else{
                            $('.no_more').show();
                            $('.zanwu').css('display','none');
                            $('.no_more').attr('num',a.pageTotal);
                            $('.no_more').attr('now','1');
                            var html = template('tpl_translation_order_list', orderinfo);
                            document.getElementById('translation_order_list').innerHTML = html;
                            prices();
                            if(a.pageTotal==1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        //滚动条滚动的时候
        $(window).scroll(function(){
            //获取当前加载更多按钮距离顶部的距离
            var bottomsubmit = $('.no_more').offset().top;
            //获取当前页面底部距离顶部的高度距离
            var nowtop = $(document).scrollTop()+$(window).height();
            //获取当前页数，默认第一页
            var now = $('.no_more').attr('now');
            //获取总页数，PHP分页的总页数
            var num = $('.no_more').attr('num');
            //当当前页面的高度大于按钮的高度的时候开始触发加载更多数据
            if(nowtop>bottomsubmit){
                //如果为真继续执行，这个是用于防止滚动获取过多的数据情况
                if(state==true){
                    //执行一次获取数据并停止再进来获取数据
                    state=false;
                    setTimeout(function(){
                        //当前页数++
                        now++;
                        //记录当前为第二页
                        $('.no_more').attr('now',now);
                        var nnow = $('.no_more').attr('now');
                        $.ajax({
                            //通过ajax传页数参数获取当前页数的数据
                            url:api+'?page='+nnow,
                            type:'get',
                            async:true,
                            cache:false,
                            data:orderdata,
                            dataType:"json",
                            success:function(a){
                                console.log(a);
                                if(a.status =='success') {
                                    //把通过php处理的html和数据，写入容器底部
                                    var orderinfo = a.result;
                                    var html = template('tpl_translation_order_list', orderinfo);
                                    // document.getElementById('translation_order_list').innerHTML = html;
                                    $('#translation_order_list').append(html);
                                    prices();
                                    //如果当前页大于等于总页数就提示没有更多数据
                                    if(now>=num){
                                        $('.no_more p').text('咩有了~');
                                        //并把状态设置为假，下次下滑滚动时不再通过ajax获取数据
                                        state=false;
                                    }else{
                                        // 否则继续
                                        state=true;
                                    }
                                }
                            },
                            error:function(XMLHttpRequest, textStatus, errorThrown){
                                $('.no_more p').text('加载错误,请刷新页面！');
                            }
                        });
                    },500);
                }
            }
        });
        function returnFloat(value){
            var value=Math.round(parseFloat(value)*100)/100;
            var xsd=value.toString().split(".");
            if(xsd.length==1){
                value=value.toString()+".00";
                return value;
            }
            if(xsd.length>1){
                if(xsd[1].length<2){
                    value=value.toString()+"0";
                }
                return value;
            }
        }
        function prices() {
            $('.order').each(function () {
                var allprice = 0;
                var onum =0;
                $(this).find('.book').each(function () {
                    var price =parseFloat($(this).find('.title h2 span').eq(0).text());
                    var num = parseInt($(this).find('.title h2 span').eq(1).text());
                    var total = price * num; //计算单个商品的总价
                    allprice += total; //计算该店铺的总价
                    onum += num;   //计算店铺商品的总数量
                })
                var fee = parseFloat($(this).find('.order_bot h1').eq(1).find('b').text());
                allprice = (parseInt(allprice*100)+parseInt(fee*100))/100;
                allprice = returnFloat(allprice);
                $(this).find('.order_bot h1').eq(0).find('b').text(onum);
                $(this).find('.order_bot h1').eq(0).find('em').text(allprice);
            })
        }
        prices();
    })
})