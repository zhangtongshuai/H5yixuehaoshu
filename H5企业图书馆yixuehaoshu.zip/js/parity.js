requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','style'],function ($,validata,template) {
        var api = validata.isApi();
        var proid= validata.getQueryString('proid');
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        //记录状态
        var state=true;
        $.ajax({
            type: 'get',
            url: api+'?page='+1,
            async:false,
            data:{
                key:key,
                module:'market',
                method:'market.contrast.'+proid,
                request_mode:'get',
                sign:sign,
                timestamp:timestamp
            },
            dataType: 'json',
            success: function (a) {
                console.log(a);
                if(a.status =='success') {
                    if(a.result.depot_many_markets.length == 1){
                        window.location.href='product_details.html?pid='+a.result.depot_many_markets[0].id;
                    }else if(a.result.depot_many_markets.length >1){
                        $('.no_more').attr('num',a.pageTotal);
                        $('.no_more').attr('now','1');
                        var parity = a.result;
                        $('.book_name .book').find('img').attr('src',parity.image);
                        $('.book_name .name h1').find('b').html(parity.name);
                        $('.choice h1 b').html(parity.depot_many_markets.length);
                        if(a.pageTotal==1){
                            $('.no_more').find('p').text('咩有了~');
                            state=false;
                        }
                        var html = template('tpl_translation_parity_list', parity.depot_many_markets);
                        document.getElementById('translation_parity_list').innerHTML = html;
                    }
                }else{
                    $('.book_name').hide();
                    $('.choice').hide();
                    $('.zanwu').show();
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
        //滚动条滚动的时候
        $(window).scroll(function(){
            //获取当前加载更多按钮距离顶部的距离
            var bottomsubmit = $('.no_more').offset().top;
            //获取当前页面底部距离顶部的高度距离
            var nowtop = $(document).scrollTop()+$(window).height();
            //获取当前页数，默认第一页
            var now = $('.no_more').attr('now');
            //获取总页数，PHP分页的总页数
            var num = $('.no_more').attr('num');
            //当当前页面的高度大于按钮的高度的时候开始触发加载更多数据
            if(nowtop>bottomsubmit){
                //如果为真继续执行，这个是用于防止滚动获取过多的数据情况
                if(state==true){
                    //执行一次获取数据并停止再进来获取数据
                    state=false;
                    setTimeout(function(){
                        //当前页数++
                        now++;
                        //记录当前为第二页
                        $('.no_more').attr('now',now);
                        $.ajax({
                            //通过ajax传页数参数获取当前页数的数据
                            url:api+'?page='+now,
                            type:'get',
                            cache:false,
                            async:false,
                            data:{
                                key:key,
                                module:'market',
                                method:'market.contrast.'+proid,
                                request_mode:'get',
                                sign:sign,
                                timestamp:timestamp
                            },
                            dataType:"json",
                            success:function(data){
                                console.log(data);
                                //把通过php处理的html和数据，写入容器底部
                                var parity = data.result;
                                var html = template('tpl_translation_parity_list', parity.depot_many_markets);
                                $('#translation_parity_list').append(html);
                                //如果当前页大于等于总页数就提示没有更多数据
                                if(now>=num){
                                    $('.no_more p').text('咩有了~');
                                    //并把状态设置为假，下次下滑滚动时不再通过ajax获取数据
                                    state=false;
                                }else{
                                    // 否则继续
                                    state=true;
                                }
                            },
                            error:function(XMLHttpRequest, textStatus, errorThrown){
                                $('.no_more p').text('加载错误,请刷新页面！');
                            }
                        });
                    },500);
                }
            }
        });

    })
})