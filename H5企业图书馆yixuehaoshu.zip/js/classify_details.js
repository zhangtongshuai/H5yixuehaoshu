requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','jqclassify','cartshow','style'],function ($,validata,template) {
        var api = validata.isApi();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var category_id = validata.getQueryString('cid');
        $('.tabs').respTabs();
        var linums = sessionStorage.getItem('linum');
        var classifydata;
        //记录状态
        var state=true;
        classifydata = {
            key:key,
            module:'market',
            method:'category.show',
            request_mode:'get',
            order_by_field:'create_time',
            sequence:'ASC',
            sign:sign,
            timestamp:timestamp,
            category_id:category_id
        };
        $(document).on('click','.pro_list',function () {
            var linum = $('.tabs-list').find('.active').attr('data_li');
            var proid = $(this).attr('proid');
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:{
                    key:key,
                    module:'market',
                    method:'market.contrast.'+proid,
                    request_mode:'get',
                    sign:sign,
                    timestamp:timestamp
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        if(a.result.depot_many_markets.length == 1){
                            sessionStorage.setItem('linum',linum);
                            window.location.href='product_details.html?pid='+a.result.depot_many_markets[0].id;
                        }else if(a.result.depot_many_markets.length >1){
                            sessionStorage.setItem('linum',linum);
                            window.location.href='parity.html?proid='+proid;
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                }
            });
        });
        if(!linums){
            $('.tabs-list').find('li').removeClass('active');
            $('.tabs-list').find('li').eq(0).addClass('active');
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:classifydata,
                dataType: 'json',
                success: function (a) {
                    //console.log(a);
                    if(a.status =='success') {
                        $('#no_more1').attr('num',a.pageTotal);
                        $('#no_more1').attr('now','1');
                        $('#translation_classify_list1').html('');
                        var address = a.result;
                        var html = template('tpl_translation_classify_list1', address);
                        document.getElementById('translation_classify_list1').innerHTML = html;
                        if(a.pageTotal<=1){
                            $('.no_more').find('p').text('咩有了~');
                            state=false;
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        }else{
            $('.tabs-list').find('li').removeClass('active');
            $('.tabs-list').find('li').eq(linums-1).addClass('active');
            if(linums == 1){
                $.ajax({
                    type: 'get',
                    url: api+'?page='+1,
                    async:false,
                    data:classifydata,
                    dataType: 'json',
                    success: function (a) {
                        //console.log(a);
                        if(a.status =='success') {
                            $('#no_more1').attr('num',a.pageTotal);
                            $('#no_more1').attr('now','1');
                            $('#translation_classify_list1').html('');
                            var address = a.result;
                            var html = template('tpl_translation_classify_list1', address);
                            document.getElementById('translation_classify_list1').innerHTML = html;
                            if(a.pageTotal<=1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }
                });
            }else if(linums == 2){
                classifydata = {
                    key:key,
                    module:'market',
                    method:'category.show',
                    request_mode:'get',
                    order_by_field:'create_time',
                    sequence:'DESC',
                    sign:sign,
                    timestamp:timestamp,
                    category_id:category_id
                };
                $.ajax({
                    type: 'get',
                    url: api+'?page='+1,
                    async:false,
                    data:classifydata,
                    dataType: 'json',
                    success: function (a) {
                        //console.log(a);
                        if(a.status =='success') {
                            $('#no_more1').attr('num',a.pageTotal);
                            $('#no_more1').attr('now','1');
                            var address = a.result;
                            var html = template('tpl_translation_classify_list1', address);
                            document.getElementById('translation_classify_list1').innerHTML = html;
                            if(a.pageTotal<=1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }
                });
            }else if(linums == 3){
                classifydata = {
                    key:key,
                    module:'market',
                    method:'category.show',
                    request_mode:'get',
                    order_by_field:'sales_number',
                    sequence:'ASC',
                    sign:sign,
                    timestamp:timestamp,
                    category_id:category_id
                }
                $.ajax({
                    type: 'get',
                    url: api+'?page='+1,
                    async:false,
                    data:classifydata,
                    dataType: 'json',
                    success: function (a) {
                        //console.log(a);
                        if(a.status =='success') {
                            $('#no_more1').attr('num',a.pageTotal);
                            $('#no_more1').attr('now','1');
                            var address = a.result;
                            var html = template('tpl_translation_classify_list1', address);
                            document.getElementById('translation_classify_list1').innerHTML = html;
                            if(a.pageTotal<=1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }
                });
            }else if(linums == 4){
                classifydata = {
                    key:key,
                    module:'market',
                    method:'category.show',
                    request_mode:'get',
                    order_by_field:'produce_date',
                    sequence:'DESC',
                    sign:sign,
                    timestamp:timestamp,
                    category_id:category_id
                }
                $.ajax({
                    type: 'get',
                    url: api+'?page='+1,
                    async:false,
                    data:classifydata,
                    dataType: 'json',
                    success: function (a) {
                        //console.log(a);
                        if(a.status =='success') {
                            $('#no_more1').attr('num',a.pageTotal);
                            $('#no_more1').attr('now','1');
                            var address = a.result;
                            var html = template('tpl_translation_classify_list1', address);
                            document.getElementById('translation_classify_list1').innerHTML = html;
                            if(a.pageTotal<=1){
                                $('.no_more').find('p').text('咩有了~');
                                state=false;
                            }
                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }
                });
            }
        }

        var category = 'category.'+ category_id;
        $.ajax({
            type: 'get',
            url: api,
            data:{
                key:key,
                module:'market',
                method:category,
                request_mode:'get',
                sign:sign,
                timestamp:timestamp,
                category_id:category_id
            },
            dataType: 'json',
            success: function (r) {
                //console.log(r);
                if(r.status =='success') {
                    $('.zhiding .classify_details_menu').html(r.result.name);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
        $('.tabs-list li').eq(0).on('click',function () {
            document.body.scrollTop = 0;
            $('#translation_classify_list1').html('');
            $('.no_more').find('p').text('上拉加载更多');
            state=true;
            classifydata = {
                key:key,
                module:'market',
                method:'category.show',
                request_mode:'get',
                order_by_field:'create_time',
                sequence:'ASC',
                sign:sign,
                timestamp:timestamp,
                category_id:category_id
            };
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:classifydata,
                dataType: 'json',
                success: function (a) {
                    //console.log(a);
                    if(a.status =='success') {
                        $('#no_more1').attr('num',a.pageTotal);
                        $('#no_more1').attr('now','1');
                        var address = a.result;
                        var html = template('tpl_translation_classify_list1', address);
                        document.getElementById('translation_classify_list1').innerHTML = html;
                        if(a.pageTotal<=1){
                            $('.no_more').find('p').text('咩有了~');
                            state=false;
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.tabs-list li').eq(1).on('click',function () {
            document.body.scrollTop = 0;
            $('#translation_classify_list1').html('');
            $('.no_more').find('p').text('上拉加载更多');
            state=true;
            classifydata = {
                key:key,
                module:'market',
                method:'category.show',
                request_mode:'get',
                order_by_field:'create_time',
                sequence:'DESC',
                sign:sign,
                timestamp:timestamp,
                category_id:category_id
            };
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:classifydata,
                dataType: 'json',
                success: function (a) {
                    //console.log(a);
                    if(a.status =='success') {
                        $('#no_more1').attr('num',a.pageTotal);
                        $('#no_more1').attr('now','1');
                        var address = a.result;
                        var html = template('tpl_translation_classify_list1', address);
                        document.getElementById('translation_classify_list1').innerHTML = html;
                        if(a.pageTotal<=1){
                            $('.no_more').find('p').text('咩有了~');
                            state=false;
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.tabs-list li').eq(2).on('click',function () {
            document.body.scrollTop = 0;
            $('#translation_classify_list1').html('');
            $('.no_more').find('p').text('上拉加载更多');
            state=true;
            classifydata = {
                key:key,
                module:'market',
                method:'category.show',
                request_mode:'get',
                order_by_field:'sales_number',
                sequence:'ASC',
                sign:sign,
                timestamp:timestamp,
                category_id:category_id
            }
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:classifydata,
                dataType: 'json',
                success: function (a) {
                    //console.log(a);
                    if(a.status =='success') {
                        $('#no_more1').attr('num',a.pageTotal);
                        $('#no_more1').attr('now','1');
                        var address = a.result;
                        var html = template('tpl_translation_classify_list1', address);
                        document.getElementById('translation_classify_list1').innerHTML = html;
                        if(a.pageTotal<=1){
                            $('.no_more').find('p').text('咩有了~');
                            state=false;
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.tabs-list li').eq(3).on('click',function () {
            document.body.scrollTop = 0;
            $('#translation_classify_list1').html('');
            $('.no_more').find('p').text('上拉加载更多');
            state=true;
            classifydata = {
                key:key,
                module:'market',
                method:'category.show',
                request_mode:'get',
                order_by_field:'produce_date',
                sequence:'DESC',
                sign:sign,
                timestamp:timestamp,
                category_id:category_id
            }
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:classifydata,
                dataType: 'json',
                success: function (a) {
                    //console.log(a);
                    if(a.status =='success') {
                        $('#no_more1').attr('num',a.pageTotal);
                        $('#no_more1').attr('now','1');
                        var address = a.result;
                        var html = template('tpl_translation_classify_list1', address);
                        document.getElementById('translation_classify_list1').innerHTML = html;
                        if(a.pageTotal<=1){
                            $('.no_more').find('p').text('咩有了~');
                            state=false;
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        //滚动条滚动的时候
        $(window).scroll(function(){
            //获取当前加载更多按钮距离顶部的距离
            var bottomsubmit = $('.no_more').offset().top;
            //获取当前页面底部距离顶部的高度距离
            var nowtop = $(document).scrollTop()+$(window).height();
            //获取当前页数，默认第一页
            var now = $('.no_more').attr('now');
            //获取总页数，PHP分页的总页数
            var num = $('.no_more').attr('num');
            //当当前页面的高度大于按钮的高度的时候开始触发加载更多数据
            if(nowtop>bottomsubmit){
                //如果为真继续执行，这个是用于防止滚动获取过多的数据情况
                if(state==true){
                    //执行一次获取数据并停止再进来获取数据
                    state=false;
                    setTimeout(function(){
                        //当前页数++
                        now++;
                        //记录当前为第二页
                        $('.no_more').attr('now',now);
                        var nnow = $('.no_more').attr('now');
                        $.ajax({
                            //通过ajax传页数参数获取当前页数的数据
                            url:api+'?page='+nnow,
                            type:'get',
                            async:true,
                            cache:false,
                            data:classifydata,
                            dataType:"json",
                            success:function(data){
                                //console.log(data);
                                //把通过php处理的html和数据，写入容器底部
                                var address = data.result;
                                var html = template('tpl_translation_classify_list1', address);
                                $('#translation_classify_list1').append(html);
                                // document.getElementById('translation_classify_list').innerHTML = html;
                                //如果当前页大于等于总页数就提示没有更多数据
                                if(now>=num){
                                    $('.no_more').find('p').text('咩有了~');
                                    //并把状态设置为假，下次下滑滚动时不再通过ajax获取数据
                                    state=false;
                                }else{
                                    // 否则继续
                                    state=true;
                                }
                            },
                            error:function(XMLHttpRequest, textStatus, errorThrown){
                                $('.no_more').find('p').text('加载错误,请刷新页面！');
                            }
                        });
                    },500);
                }
            }
        });
        var share_url = location.href.split('#')[0];
        var referee = window.btoa(uid); //字符串编码
        var source = window.location.href;
        var refereeurl = source +'&referee='+referee;
        $.ajax({
            type: 'post',
            url: api,
            data:{
                module:'member',
                method:'wechat.share',
                request_mode:'post',
                key:key,
                sign:sign,
                timestamp:timestamp,
                share_url:share_url
            },
            dataType: 'json',
            success: function (a) {
                console.log(a)
                if(a.status == 'success'){
                    var appId = 'wx1048afd03302531b';
                    var timestamp = parseInt(a.result.timestamp);
                    var nonceStr = a.result.noncestr;
                    var signature = a.result.signature;
                    wx.config({
                        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                        appId: appId, // 必填，公众号的唯一标识
                        timestamp: timestamp, // 必填，生成签名的时间戳
                        nonceStr: nonceStr, // 必填，生成签名的随机串
                        signature: signature,// 必填，签名，见附录1
                        jsApiList: ['onMenuShareTimeline','onMenuShareAppMessage'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                    });
                    wx.ready(function(){
                        wx.onMenuShareTimeline({
                            title: '您想看的医学好书，都在这', // 分享标题
                            desc: '医学类的图书，应有尽有', // 分享描述
                            link:refereeurl, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                            imgUrl: 'http://m.yixuehaoshu.com/img/logo.jpg', // 分享图标
                            success: function () {
                                // 用户点击了分享后执行的回调函数
                                alert('分享成功');
                            },
                            cancel: function () {
                                alert('分享失败,您取消了分享!')
                            }
                        });
                        wx.onMenuShareAppMessage({
                            title: '您想看的医学好书，都在这', // 分享标题
                            desc: '医学类的图书，应有尽有', // 分享描述
                            link: refereeurl, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                            imgUrl: 'http://m.yixuehaoshu.com/img/logo.jpg', // 分享图标
                            success: function () {
                                alert('分享成功');
                                // 用户点击了分享后执行的回调函数
                            },
                            cancel: function () {
                                alert('分享失败,您取消了分享!')
                            }
                        });
                    });
                }
            }
        })
    })
});