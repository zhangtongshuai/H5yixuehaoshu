requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','cartshow','style'],function ($,validata,template) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var market_number = validata.getQueryString('market_number');
        var market_id = validata.getQueryString('market_id');
        var cart_id = validata.getQueryString('cart_ids');
        if(cart_id){
            $('.address').find('.add_address').attr('href','add_address.html?cart_ids='+cart_id);
        }else if(market_number && market_id){
            $('.address').find('.add_address').attr('href','add_address.html?market_id='+market_id+'&market_number='+market_number)
        }else{
            $('.address').find('.add_address').attr('href','add_address.html');
        }
        $.ajax({
            type: 'post',
            url: api+'?uid='+uid,
            data:{
                key:key,
                module:'member',
                method:'address.get_all',
                request_mode:'post',
                sign:sign,
                timestamp:timestamp
            },
            dataType: 'json',
            success: function (a) {
                console.log(a);
                if(a.status =='success') {
                    $('.no_more').attr('num',a.pageTotal);
                    var address = a.result;
                    var html = template('tpl_translation_address_list', address);
                    document.getElementById('translation_address_list').innerHTML = html;
                    $('.address_list .address_info').on('click',function () {
                        var address_id = $(this).parents('.address_list').attr('address_id');
                        var consignee_address = $(this).find('.list_con').text();
                        var consignee_name = $(this).find('.list_top').find('span').eq(0).text();
                        if(cart_id){
                            sessionStorage.setItem('consignee_name',consignee_name);
                            sessionStorage.setItem('consignee_address',consignee_address);
                            window.location.href= 'order_generate.html?cart_ids='+cart_id+'&address_id='+address_id;
                        }else if(market_number && market_id){
                            sessionStorage.setItem('consignee_name',consignee_name);
                            sessionStorage.setItem('consignee_address',consignee_address);
                            window.location.href= 'order_generate.html?market_id='+market_id+'&market_number='+market_number+'&address_id='+address_id;
                        }
                    })
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
            }
        });
        $(document).on('click','.delete',function () {
            var a_id = $(this).parents('.address_list').attr('address_id');
            $('.seller_contact4').attr('a_id',a_id);
            $('.seller_contact4').show();
        });
        $('.seller_contact_button').find('a').eq(0).on('click',function () {
            var ad_id = $('.seller_contact4').attr('a_id');
            $.ajax({
                type: 'post',
                url: api+'?address_id='+ad_id+'&uid='+uid,
                data:{
                    key:key,
                    module:'member',
                    method:'address.delete',
                    request_mode:'post',
                    sign:sign,
                    timestamp:timestamp
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        $('#'+ad_id).remove();
                        $('.seller_contact4').hide();
                    }else{
                        alert(a.msg);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                }
            });
        });
        function adress(address_id) {
            $.ajax({
                type: 'post',
                url: api+'?address_id='+address_id+'&uid='+uid,
                data:{
                    key:key,
                    module:'member',
                    method:'address.set_default',
                    request_mode:'post',
                    sign:sign,
                    timestamp:timestamp
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        // if(cart_id){
                        //     window.location.href= 'order_generate.html?cart_ids='+cart_id;
                        // }
                    }else{
                        alert(a.msg);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                }
            });
        }
        $(document).on('click','.list_bot .list_bot_left',function () {
            $('label input').attr('checked',false);
            $(this).parents('.address_list').find('label input').attr('checked',true);
            var address_id = $(this).parents('.address_list').attr('address_id');
            adress(address_id);
        });
        $(document).on('click','label span',function () {
            $('label input').attr('checked',false);
            var address_id = $(this).parents('.address_list').attr('address_id');
            adress(address_id);
        });
        $(document).on('click','.edit',function () {
            var consignee = $(this).parents('.address_list').find('.list_top span').eq(0).html();
            var mobile = $(this).parents('.address_list').find('.list_top span').eq(1).html();
            var address =  $(this).parents('.address_list').find('.addressinfo').html();
            var is_default;
            var isdefault = $(this).parents('.address_list').find('label input').get(0).checked;
            if(isdefault){
                is_default = 1;
            }else{
                is_default = 0;
            }
            sessionStorage.setItem('consignee',consignee);
            sessionStorage.setItem('mobile',mobile);
            sessionStorage.setItem('address',address);
            sessionStorage.setItem('is_default',is_default);
            var address_id = $(this).parents('.address_list').attr('address_id');
            var add_address_url = 'add_address.html?address_id='+address_id;
            window.location.href=add_address_url;
        })
    })
});