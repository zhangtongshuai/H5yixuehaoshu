requirejs(['common'],function(c){
    requirejs(['jquery','swiper','validata','cartshow','style'],function ($,swiper,validata) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var input  = /^[\s]*$/;
        //记录状态
        var state=true;
        window.addEventListener("beforeunload", function(e) {
            $('.search .search_info').val('');
        });
        $('.search button').on('click',function () {
            var code;
            var goods_name;
            var searchval = $('.search_info').val();
            if(input.test(searchval)){
                alert('没有输入内容');
                return false;
            }else if( !isNaN( searchval ) ) {
                 code = searchval;
                 goods_name = '';
            }else{
                 code = '';
                 goods_name = searchval;
            }
            $.ajax({
                type: 'get',
                async:true,
                url: api,
                data:{
                    code:code,
                    goods_name:goods_name,
                    module:'market',
                    method:'market',
                    request_mode:'get',
                    key:key,
                    sign:sign,
                    timestamp:timestamp
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        if(a.result == ''){
                            alert('没有查询到内容');
                        }else{
                            $('.product ul').html('');
                            $('.no_more').attr('num',a.pageTotal);
                            $('.no_more').attr('now','1');
                            state=true;
                            var indexlist = '';
                            for(var i=0;i<a.result.length;i++){
                                var index = a.result[i];
                                indexlist +='<li class="pro_list" proid='+index.id+'><div class="productLeft"><img src="'+index.image+'"></div><div class="productRight"><h1>'+index.name+'</h1><div class="price"><h2>￥'+index.min_price+'</h2><del>￥'+index.price+'</del></div></div></li>';
                            }
                            $('.product ul').append(indexlist);
                            if(a.pageTotal<=1){
                                $('.no_more p').text('咩有了~');
                            }else{
                                $('.no_more p').text('上拉加载更多');
                            }
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        //banner列表
        $.ajax({
            type: 'get',
            async:true,
            url: api,
            data:{
                module:'system',
                method:'carousel',
                request_mode:'get',
                page:'1',
                key:key,
                sign:sign,
                timestamp:timestamp
            },
            dataType: 'json',
            success: function (a) {
                //console.log(a);
                if(a.status =='success') {
                    var bannerlist = '';
                    for(var i=0;i<a.result.length;i++){
                        var banner = a.result[i];
                        var bannerurl = banner.redirect_url;
                        var url1 = bannerurl.split('/');
                        var pid = url1[url1.length-1];
                        bannerlist +='<div class="swiper-slide"><a href="product_details.html?pid='+pid+'"><img src="'+banner.image+'"></a></div>';
                    }
                    $('.swiper-wrapper').append(bannerlist);
                    var mySwiper = new Swiper ('.swiper-container', {
                        direction: 'horizontal',
                        loop: true,
                        autoplay:3000,
                        // autoplay:true,
                        // 如果需要分页器
                        pagination: '.swiper-pagination'
                    });
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
        //图书列表
        $.ajax({
            type: 'get',
            async:true,
            url: api+'?page='+1,
            data:{
                module:'market',
                method:'market',
                request_mode:'get',
                key:key,
                sign:sign,
                timestamp:timestamp
            },
            dataType: 'json',
            success: function (a) {
                //console.log(a);
                if(a.status =='success') {
                    $('.no_more').attr('num',a.pageTotal);
                    var indexlist = '';
                    for(var i=0;i<a.result.length;i++){
                        var index = a.result[i];
                        indexlist +='<li class="pro_list" proid='+index.id+'><div class="productLeft"><img src="'+index.image+'"></div><div class="productRight"><h1>'+index.name+'</h1><div class="price"><h2>￥'+index.min_price+'</h2><del>￥'+index.price+'</del></div></div></li>';
                    }
                    $('.product ul').append(indexlist);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
        $(document).on('click','.pro_list',function () {
            var proid = $(this).attr('proid');
            $.ajax({
                type: 'get',
                url: api+'?page='+1,
                async:false,
                data:{
                    key:key,
                    module:'market',
                    method:'market.contrast.'+proid,
                    request_mode:'get',
                    sign:sign,
                    timestamp:timestamp
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        if(a.result.depot_many_markets.length == 1){
                            window.location.href='product_details.html?pid='+a.result.depot_many_markets[0].id;
                        }else if(a.result.depot_many_markets.length >1){
                            window.location.href='parity.html?proid='+proid;
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                }
            });
        });
        //滚动条滚动的时候
        $(window).scroll(function(){
            //获取当前加载更多按钮距离顶部的距离
            var bottomsubmit = $('.no_more').offset().top;
            //获取当前页面底部距离顶部的高度距离
            var nowtop = $(document).scrollTop()+$(window).height();
            //获取当前页数，默认第一页
            var now = $('.no_more').attr('now');
            //获取总页数，PHP分页的总页数
            var num = $('.no_more').attr('num');
            //当当前页面的高度大于按钮的高度的时候开始触发加载更多数据
            if(nowtop>bottomsubmit){
                //如果为真继续执行，这个是用于防止滚动获取过多的数据情况
                if(state==true){
                    //执行一次获取数据并停止再进来获取数据
                    state=false;
                    setTimeout(function(){
                        //当前页数++
                        now++;
                        //记录当前为第二页
                        $('.no_more').attr('now',now);
                        $.ajax({
                            //通过ajax传页数参数获取当前页数的数据
                            url:api+'?page='+now,
                            type:'get',
                            cache:false,
                            data:{
                                module:'market',
                                method:'market',
                                request_mode:'get',
                                key:key,
                                sign:sign,
                                timestamp:timestamp
                            },
                            dataType:"json",
                            success:function(data){
                                console.log(data);
                                //把通过php处理的html和数据，写入容器底部
                                var indexlist = '';
                                for(var i=0;i<data.result.length;i++){
                                    var index = data.result[i];
                                    indexlist +='<li class="pro_list" proid='+index.id+'><div class="productLeft"><img src="'+index.image+'"></div><div class="productRight"><h1>'+index.name+'</h1><div class="price"><h2>￥'+index.min_price+'</h2><del>￥'+index.price+'</del></div></div></li>';
                                }
                                $('.product ul').append(indexlist);
                                //如果当前页大于等于总页数就提示没有更多数据
                                if(now>=num){
                                    $('.no_more p').text('咩有了~');
                                    //并把状态设置为假，下次下滑滚动时不再通过ajax获取数据
                                    state=false;
                                }else{
                                    // 否则继续
                                    state=true;
                                }
                            },
                            error:function(XMLHttpRequest, textStatus, errorThrown){
                                $('.no_more p').text('加载错误,请刷新页面！');
                            }
                        });
                    },500);
                }
            }
        });
        var share_url = location.href.split('#')[0];
        var referee = window.btoa(uid); //字符串编码
        var source = 'http://m.yixuehaoshu.com/index.html';
        var refereeurl = source +'?referee='+referee;
        $.ajax({
            type: 'post',
            url: api,
            data:{
                module:'member',
                method:'wechat.share',
                request_mode:'post',
                key:key,
                sign:sign,
                timestamp:timestamp,
                share_url:share_url
            },
            dataType: 'json',
            success: function (a) {
                console.log(a)
                if(a.status == 'success'){
                    var appId = 'wx1048afd03302531b';
                    var timestamp = parseInt(a.result.timestamp);
                    var nonceStr = a.result.noncestr;
                    var signature = a.result.signature;
                    wx.config({
                        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                        appId: appId, // 必填，公众号的唯一标识
                        timestamp: timestamp, // 必填，生成签名的时间戳
                        nonceStr: nonceStr, // 必填，生成签名的随机串
                        signature: signature,// 必填，签名，见附录1
                        jsApiList: ['onMenuShareTimeline','onMenuShareAppMessage'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                    });
                    wx.ready(function(){
                        wx.onMenuShareTimeline({
                            title: '您想看的医学好书，都在这', // 分享标题
                            desc: '医学类的图书，应有尽有', // 分享描述
                            link:refereeurl, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                            imgUrl: 'http://m.yixuehaoshu.com/img/logo.jpg', // 分享图标
                            success: function () {
                                // 用户点击了分享后执行的回调函数
                                alert('分享成功');
                            },
                            cancel: function () {
                                alert('分享失败,您取消了分享!')
                            }
                        });
                        wx.onMenuShareAppMessage({
                            title: '您想看的医学好书，都在这', // 分享标题
                            desc: '医学类的图书，应有尽有', // 分享描述
                            link: refereeurl, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                            imgUrl: 'http://m.yixuehaoshu.com/img/logo.jpg', // 分享图标
                            success: function () {
                                alert('分享成功');
                                // 用户点击了分享后执行的回调函数
                            },
                            cancel: function () {
                                alert('分享失败,您取消了分享!')
                            }
                        });
                    });
                }
            }
        })
    })
});