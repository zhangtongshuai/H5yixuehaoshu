requirejs.config({
    paths:{
        jquery:'jquery-1.7.2.min',
        swiper:'swiper-3.4.2.jquery.min',
        style:'style',
        upload:'uploadPreview',
        zclip:'jquery.zclip',
        shopping:'shopping',
        jqclassify:'jquery.classify',
        base:'base',
        template:'template',
        jsaddress:'jsAddress',
        md5:'md5',
        cartshow:'cartshow'
    },
    shim: {
        "swiper":{
            deps: ['jquery']
        },
        "style":{
            deps: ['jquery']
        },
        "upload":{
            deps: ['jquery']
        },
        "zclip":{
            deps: ['jquery']
        },
        "jqclassify":{
            deps: ['jquery']
        },
        "shopping":{
            deps: ['jquery']
        },
        "base":{
            deps: ['jquery']
        },
        "template":{
            deps: ['jquery']
        },
        "jsaddress":{
            deps: ['jquery']
        },
        "md5":{
            deps: ['jquery']
        },
        "cartshow":{
            deps: ['jquery']
        }
    }
})