requirejs(['common'],function(c){
    requirejs(['jquery','swiper','validata','cartshow','style'],function ($,swiper,validata) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var openid = validata.isOpenid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var product_id;
        var rpid;
        if(validata.getQueryString('pid')){
            product_id = validata.getQueryString('pid');
        }else if(validata.getQueryString('rpid')){
            rpid = validata.getQueryString('rpid');
            var refereeid = window.atob(rpid);
            var re_arr = refereeid.split("/");
            product_id = re_arr[0];
            var ruid = re_arr[1];
            if(uid != ruid){
                $.ajax({
                    type: 'post',
                    url: api,
                    data:{
                        key:key,
                        module:'member',
                        method:'user.store_referee_relation',
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid,
                        referee:ruid
                    },
                    dataType: 'json',
                    success: function (a) {
                        if(a.status =='success') {

                        }else{
                            alert(a.msg)
                        }
                    }
                });
            }
        }

        var productinfo = 'market.'+product_id;
        var seller;
        var market_id;
        var market_image;
        var market_name;
        var market_price;
        var share_img;
        $.ajax({
            type: 'get',
            url: api,
            async:false,
            data:{
                key:key,
                module:'market',
                method:productinfo,
                page:1,
                request_mode:'get',
                sign:sign,
                timestamp:timestamp
            },
            dataType: 'json',
            success: function (a) {
                console.log(a);
                if(a.status =='success') {
                    if(a.result.status == 1){
                        $('.subnav .subnav_right').css('display','flex');
                    }else{
                        $('.subnav .subnav_right1').css('display','flex');
                    }
                    var product = a.result.market_many_image;
                    var productimg = '';
                    if(product!=''){
                        for(var i=0;i<product.length;i++){
                            productimg += '<div class="swiper-slide"><img src="'+product[i].image+'"></div>'
                        }
                        $('.product_details .swiper-wrapper').append(productimg);
                        market_image = product[0].image;
                        share_img = product[0].image;
                        if(product.length>1){
                            var mySwiper = new Swiper ('.swiper-container', {
                                direction: 'horizontal',
                                loop: true,
                                autoplay:3000,
                                // autoplay:true,
                                // 如果需要分页器
                                pagination: '.swiper-pagination',
                            });
                        }
                    }
                    $('.product_name').find('h1').html(a.result.name);
                    $('.product_name').find('.price h2 b').html(a.result.price);
                    $('.product_name').find('.price del b').html(a.result.original_price);
                    $('.product_name').find('.price h3 b').html(a.result.discount);
                    $('.product_name').find('h4 b').html(a.result.number);
                    if(a.result.produce_date!=null){
                        var t = a.result.produce_date;
                        var publishdate = new Date(Date.parse(t.replace(/-/g,"/")));
                        var publish_date = publishdate.getFullYear() + "-" + (publishdate.getMonth() + 1) + "-" + publishdate.getDate();
                        $('.introduce ul').find('li').eq(1).find('p').html(publish_date);
                    }else{
                        $('.introduce ul').find('li').eq(1).find('p').html('');
                    }

                    if(a.result.markets_one_fee !=null){
                        $('.introduce ul').find('li').eq(0).find('p').find('b').html(a.result.markets_one_fee.base_fee);
                        $('.introduce ul').find('li').eq(0).find('p').find('em').html(a.result.markets_one_fee.max_fee);
                    }
                    $('.introduce ul').find('li').eq(2).find('p').html(a.result.author);
                    $('.introduce ul').find('li').eq(3).find('p').html(a.result.manufactor);
                    $('.introduce ul').find('li').eq(4).find('p').html(a.result.pages);
                    $('.introduce ul').find('li').eq(5).find('p').html(a.result.code);
                    if(a.result.markets_one_member !=null){
                        $('.seller .seller_top').find('img').attr('src',a.result.markets_one_member.avatar);
                        $('.seller .seller_top').find('div h1').html(a.result.markets_one_member.name);
                        $('.seller .seller_top').find('div h2').html(a.result.markets_one_member.province_name + a.result.markets_one_member.city_name);
                        if(a.result.markets_one_member.qrcode != ''){
                            $('.seller_contact .seller_contact_bot .seller_contact_ewm').find('img').attr('src',a.result.markets_one_member.qrcode);
                        }else{
                            $('.seller_contact .seller_contact_bot .seller_contact_ewm').hide();
                        }
                        $('.seller_contact .seller_contact_bot a').eq(0).find('b').html(a.result.markets_one_member.mobile);
                        var tel = 'tel://'+a.result.markets_one_member.mobile;
                        $('.seller_contact .seller_contact_bot a').eq(0).attr('href',tel);
                        $('.seller_contact .seller_contact_bot a').eq(1).find('b').html(a.result.markets_one_member.brief);
                        $('.seller_contact .seller_contact_bot a').eq(2).find('b').html(a.result.markets_one_member.province_name+a.result.markets_one_member.city_name+a.result.markets_one_member.address);
                        seller = a.result.markets_one_member.uid;
                    }else{
                        $('.seller_contact .seller_contact_bot .seller_contact_ewm').hide();
                    }
                    $('.details').find('p').html(a.result.brief);
                    market_id = a.result.id;
                    market_name = a.result.name;
                    market_price = a.result.price;
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
            }
        });
        $(".subnav .subnav_right a").eq(0).click(function(){
            $('#market_number').attr('dclick','1');
        });
        $(".subnav .subnav_right a").eq(1).click(function(){
            $('#market_number').attr('dclick','2');
        });
        $('.attribute_contact_button a').eq(1).on('click',function () {
            var market_number = $('#market_number').val();
            var dclick = $('#market_number').attr('dclick');
            if(dclick == 1){
                $.ajax({
                    type: 'post',
                    url: api+'?market_number='+market_number+'&market_id='+market_id,
                    async:false,
                    data:{
                        buyer:uid,
                        key:key,
                        market_image:market_image,
                        market_name:market_name,
                        market_price:market_price,
                        market_type:'1',
                        module:'order',
                        method:'cart',
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        seller:seller
                    },
                    dataType: 'json',
                    success: function (a) {
                        console.log(a);
                        if(a.status =='success') {
                            $('.attribute').hide();
                            $('.subnav a').find('b').show();
                            $('.nav a').find('b').show();
                        }else{
                            alert(a.msg);
                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }
                });
            }
            if(dclick == 2){
                window.location.href = 'order_generate.html?market_id='+market_id+'&market_number='+market_number;
            }
        });
        var share_title = $('.product_name').find('h1').text();
        var share_url = location.href.split('#')[0];
        var referee = window.btoa(uid); //字符串编码
        var source = window.location.href;
        var refereeurl = source +'&referee='+referee;
        $.ajax({
            type: 'post',
            url: api,
            data:{
                module:'member',
                method:'wechat.share',
                request_mode:'post',
                key:key,
                sign:sign,
                timestamp:timestamp,
                share_url:share_url
            },
            dataType: 'json',
            success: function (a) {
                console.log(a)
                if(a.status == 'success'){
                    var appId = 'wx1048afd03302531b';
                    var timestamp = parseInt(a.result.timestamp);
                    var nonceStr = a.result.noncestr;
                    var signature = a.result.signature;
                    wx.config({
                        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                        appId: appId, // 必填，公众号的唯一标识
                        timestamp: timestamp, // 必填，生成签名的时间戳
                        nonceStr: nonceStr, // 必填，生成签名的随机串
                        signature: signature,// 必填，签名，见附录1
                        jsApiList: ['onMenuShareTimeline','onMenuShareAppMessage'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                    });
                    wx.ready(function(){
                        wx.onMenuShareTimeline({
                            title: share_title, // 分享标题
                            desc: '医学类的图书，应有尽有', // 分享描述
                            link:refereeurl, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                            imgUrl: share_img, // 分享图标
                            success: function () {
                                // 用户点击了分享后执行的回调函数
                                alert('分享成功');
                            },
                            cancel: function () {
                                alert('分享失败,您取消了分享!')
                            }
                        });
                        wx.onMenuShareAppMessage({
                            title: share_title, // 分享标题
                            desc: '医学类的图书，应有尽有', // 分享描述
                            link: refereeurl, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                            imgUrl: share_img, // 分享图标
                            success: function () {
                                alert('分享成功');
                                // 用户点击了分享后执行的回调函数
                            },
                            cancel: function () {
                                alert('分享失败,您取消了分享!')
                            }
                        });
                    });
                }
            }
        })
    })
});