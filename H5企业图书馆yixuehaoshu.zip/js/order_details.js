requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','zclip','style'],function ($,validata,template) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var openid = validata.isOpenid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var o_id = validata.getQueryString('oid');
        function returnFloat(value){
            var value=Math.round(parseFloat(value)*100)/100;
            var xsd=value.toString().split(".");
            if(xsd.length==1){
                value=value.toString()+".00";
                return value;
            }
            if(xsd.length>1){
                if(xsd[1].length<2){
                    value=value.toString()+"0";
                }
                return value;
            }
        }
        function timestampToTimeMD(timestamp) {
            var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
            var Y = date.getFullYear() + '-';
            var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
            var D = (date.getDate()<10?'0'+date.getDate():date.getDate()) + ' ';
            var h = (date.getHours()<10?'0'+date.getHours():date.getHours()) + ':';
            var m = date.getMinutes()<10?'0'+date.getMinutes():date.getMinutes();
            return M+D;
        }
        function timestampToTimehm(timestamp) {
            var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
            var Y = date.getFullYear() + '-';
            var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
            var D = (date.getDate()<10?'0'+date.getDate():date.getDate()) + ' ';
            var h = (date.getHours()<10?'0'+date.getHours():date.getHours()) + ':';
            var m = date.getMinutes()<10?'0'+date.getMinutes():date.getMinutes();
            return h+m;
        }
        $.ajax({
            type: 'post',
            url: api+'?order_id='+o_id,
            async:false,
            data:{
                key:key,
                module:'order',
                method:'order.detail',
                request_mode:'post',
                sign:sign,
                timestamp:timestamp,
                uid:uid,
                user_type:'2'
            },
            dataType: 'json',
            success: function (a) {
                console.log(a);
                if(a.status =='success') {
                    var orderinfo = a.result;
                    var orderstatus;
                    if(orderinfo.status == 1){
                        orderstatus = '待付款';
                        $('.order_pay .pay_off a').eq(0).show();
                        $('.order_pay .pay_off a').eq(1).show();
                        $('.order_pay .pay_off a').eq(2).show();
                    }else if(orderinfo.status == 2){
                        orderstatus = '待发货';
                        $('.order_pay .pay_off a').eq(0).show();
                        $('.order_pay .pay_off a').eq(1).show();
                    }else if(orderinfo.status == 3){
                        orderstatus = '待收货';
                        $('.order_pay .pay_bot a').eq(0).show();
                        $('.order_pay .pay_bot a').eq(1).show();
                        var address_info = '[收货地址]'+orderinfo.province+orderinfo.city+orderinfo.district+orderinfo.address;
                        $('.express_progress .express .express_address').eq(0).find('.address_right').find('p').text(address_info);
                        var express_company= orderinfo.express_company;
                        var express_no = orderinfo.express_no;
                        var order_no = orderinfo.order_no;
                        $('.order_address_bot #link').text(express_no);
                        $('.order_address_bot').show();
                        $('.express_progress').show();
                        $.ajax({
                            url: api,
                            type: 'get',
                            data: {
                                express_company:express_company,
                                express_no:express_no,
                                key: key,
                                sign: sign,
                                timestamp: timestamp,
                                method: 'order.'+order_no+'.logistics',
                                module: 'order',
                                request_mode: 'get'
                            },
                            dataType: 'json',
                            success: function (b) {
                                if(b.State){
                                    if(b.State ==3){
                                        var express_info= '';
                                        var num = b.Traces.length;
                                        for(var j=0;j<num;j++){
                                            express_info+='<div class="express_infor"><div class="infor_left"><span>'+timestampToTimeMD(b.Traces[j].AcceptTime)+'</span><font>'+timestampToTimehm(b.Traces[j].AcceptTime)+'</font></div><div class="infor_right"><span></span><p>'+b.Traces[j].AcceptStation+'</p></div><div style="clear:both"></div></div>';
                                        }
                                        $('.express_progress .expressinfo').append(express_info);
                                        $('.express_progress .expressinfo .express_infor').eq(0).find('.infor_right').addClass('active');
                                        $('.express_progress .express .express_address').eq(1).find('.address_left').find('span').text(timestampToTimeMD(b.Traces[num-1].AcceptTime));
                                        $('.express_progress .express .express_address').eq(1).find('.address_left').find('font').text(timestampToTimehm(b.Traces[num-1].AcceptTime));
                                        $('.express_progress .express .express_address').eq(1).find('.address_right').find('p b').text(b.Traces[num-1].AcceptStation);
                                    }
                                }
                            }
                        });
                        $('.order_pay .pay_bot a').eq(1).on('click',function () {
                            $('.seller_contact5').show();
                        })
                    }else if(orderinfo.status == 4){
                        orderstatus = '已成交';
                        $('.order_pay .pay_bot a').eq(0).show();
                    }else if(orderinfo.status == -1){
                        orderstatus = '已取消';
                        $('.order_pay .pay_bot a').eq(0).show();
                    }else if(orderinfo.status == 5){
                        orderstatus = '已取消（退款中）';
                        $('.order_pay .pay_bot a').eq(0).show();
                    }else if(orderinfo.status == 6){
                        orderstatus = '已取消（退款成功）';
                        $('.order_pay .pay_bot a').eq(0).show();
                    }
                    $('.order_state .order_state_left h1').text(orderstatus);
                    $('.order_top .span1').text(orderstatus);
                    $('.order_details_address .order_address_top .link').eq(0).find('p').find('b').text(orderinfo.consignee);
                    $('.order_details_address .order_address_top .link').eq(0).find('p').find('em').text(orderinfo.mobile);
                    $('.order_details_address .order_address_top .link').eq(1).find('p').text(orderinfo.province+orderinfo.city+orderinfo.district+orderinfo.address);
                    if(orderinfo.referee_info != null){
                        $('.tjr h1').text(orderinfo.referee_info.name);
                    }
                    $('.liuyan span').text(orderinfo.remark);
                    if(orderinfo.shop!=null){
                        $('.order_top .title img').attr('src',orderinfo.shop.avatar);
                        $('.order_top .title h1').text(orderinfo.shop.name);
                        $('.seller_contact .seller_contact_bot a').eq(0).find('b').text(orderinfo.shop.mobile);
                        $('.seller_contact .seller_contact_bot a').eq(1).find('b').text(orderinfo.shop.brief);
                        $('.seller_contact .seller_contact_bot a').eq(2).find('b').text(orderinfo.shop.province_name+orderinfo.shop.city_name+orderinfo.shop.address);
                        if(orderinfo.shop.qrcode ==null || orderinfo.shop.qrcode ==''){
                            $('.seller_contact .seller_contact_ewm img').hide();
                            $('.seller_contact .seller_contact_ewm').css('padding-bottom','20px')
                        }else{
                            $('.seller_contact .seller_contact_ewm img').attr('src',orderinfo.shop.qrcode);
                        }
                    }else{
                        $('.seller_contact .seller_contact_ewm img').hide();
                        $('.seller_contact .seller_contact_ewm').css('padding-bottom','20px')
                    }

                    $('.order_no .order_infor').eq(0).find('p').text(orderinfo.order_no);
                    $('.order_no .order_infor').eq(1).find('p').text(orderinfo.created_at);
                    var html = template('tpl_translation_order_list', orderinfo.ordergoods);
                    document.getElementById('translation_order_list').innerHTML = html;
                    var oprice = 0; //店铺总价
                    var onum = 0;
                    $('.book').each(function () {
                        var num = parseInt($(this).find(".title h2 em").text()); //得到商品的数量
                        var price = parseFloat($(this).find(".title h2 b").text()); //得到商品的单价
                        var total = price * num; //计算单个商品的总价
                        oprice += total; //计算该店铺的总价
                        onum += num;   //计算店铺商品的总数量
                        oprice = returnFloat(oprice);
                    });
                    $('.order_bot h1').eq(0).find('b').text(onum);
                    $('.order_bot h1').eq(1).find('b').text(orderinfo.shipping_fee);
                    oprice = (oprice*100+orderinfo.shipping_fee*100)/100;
                    oprice = returnFloat(oprice);
                    $('.order_bot h1').eq(0).find('em').text(oprice);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
        $(document).on('click','.book',function () {
            var pid = $(this).attr('pid');
            window.location.href='product_details.html?pid='+pid;
        });
        //复制单号
        $('#copyBtn').on('click',function () {
            $('.order_address_bot #link').select();
            document.execCommand("Copy");
            alert("已复制好，可贴粘。");
        });
        $('.seller_contact5 .seller_contact_button a').eq(1).on('click',function () {
            $.ajax({
                url: api,
                type: 'post',
                data: {
                    key: key,
                    sign: sign,
                    timestamp: timestamp,
                    method: 'order.confirm',
                    module: 'order',
                    request_mode: 'post',
                    order_id:o_id,
                    uid:uid
                },
                dataType: 'json',
                success: function (b) {
                    if(b.status=='success'){
                        $('.seller_contact5').hide();
                        window.location.reload();
                    }else{
                        alert('操作失败');
                    }
                }
            })
        });
        $('.order_pay .pay_off .cancel_order').on('click',function () {
            $('.seller_contact4').show();
        });
        $('.seller_contact4 .seller_contact_button a').eq(0).on('click',function () {
            $.ajax({
                type: 'post',
                url: api,
                data:{
                    key:key,
                    module:'order',
                    method:'order.cancel',
                    request_mode:'post',
                    order_id:o_id,
                    sign:sign,
                    timestamp:timestamp,
                    uid:uid,
                    user_type:'2'
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        window.location.href='order.html';
                    }else{
                        alert(a.msg)
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        });
        $('.order_pay .pay_off .payment_btn').click(function () {
            $('.seller_contact3').show();
        });
        $('.seller_contact3 .seller_contact_button a').eq(0).on('click',function () {
            var total = $('.order_bot h1').eq(0).find('em').text();
            $.ajax({
                type: 'post',
                url: api,
                async: true,
                data:{
                    key:key,
                    module:'order',
                    method:'order.store_charge',
                    request_mode:'post',
                    order_id:o_id,
                    sign:sign,
                    total:total,
                    timestamp:timestamp,
                    uid:uid,
                    user_type:'2'
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        var out_trade_no = a.result.charge_no;
                        var total_fee = total*100;
                        var body = '1111';
                        $.ajax({
                            type: 'get',
                            async: true,
                            url: 'http://librarypay.zhongmeiyixue.com/wechat/mp?out_trade_no='+out_trade_no+'&body='+body+'&total_fee='+total_fee+'&openid='+openid,
                            dataType: 'json',
                            success: function (b) {
                                console.log(b);
                                var appId = b.appId;
                                var timestamp = parseInt(b.timeStamp);
                                var nonceStr = b.nonceStr;
                                var paySign = b.paySign;
                                var package = b.package;
                                var signType = b.signType;
                                wx.config({
                                    debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                                    appId: appId, // 必填，公众号的唯一标识
                                    timestamp: timestamp, // 必填，生成签名的时间戳
                                    nonceStr: nonceStr, // 必填，生成签名的随机串
                                    jsApiList: ['chooseWXPay'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                                });
                                wx.ready(function(){
                                    wx.chooseWXPay({
                                        timestamp:timestamp,
                                        nonceStr:nonceStr,
                                        package : package,
                                        signType :signType,
                                        paySign :paySign,
                                        success: function (d) {
                                            window.location.href='order.html';
                                        }
                                    });
                                });
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                // alert(XMLHttpRequest.status);
                                // alert(XMLHttpRequest.readyState);
                                // alert(textStatus);
                            }
                        });
                    }else{
                        alert(a.msg)
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
        })
    })
});