requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','style'],function ($,validata,template) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var openid = validata.isOpenid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var market_number = validata.getQueryString('market_number');
        var market_id = validata.getQueryString('market_id');
        var cart_id = validata.getQueryString('cart_ids');
        var addressid = validata.getQueryString('address_id');
        var consignee_name = sessionStorage.getItem('consignee_name');
        var consignee_address = sessionStorage.getItem('consignee_address');
        function returnFloat(value){
            var value=Math.round(parseFloat(value)*100)/100;
            var xsd=value.toString().split(".");
            if(xsd.length==1){
                value=value.toString()+".00";
                return value;
            }
            if(xsd.length>1){
                if(xsd[1].length<2){
                    value=value.toString()+"0";
                }
                return value;
            }
        }
        window.addEventListener("beforeunload", function(e) {
            sessionStorage.removeItem('consignee_name');
            sessionStorage.removeItem('consignee_address');
        });
        var pdataurl;
        var pdata;
        var address_id;
        $.ajax({
            type: 'post',
            url: api+'?uid='+uid,
            async:false,
            data:{
                key:key,
                module:'member',
                method:'address.show_default',
                request_mode:'post',
                sign:sign,
                timestamp:timestamp
            },
            dataType: 'json',
            success: function (a) {
                //console.log(a);
                if(a.status =='success') {
                    if(a.result == null){
                        $('.order_address').hide();
                        $('.order_info').hide();
                        $('.order_info1').hide();
                        $('.order_pay').hide();
                        $('.seller_contact6').show();
                    }else{
                        $('.order_pay .pay_bot a').show();
                        address_id = a.result.id;
                        if(addressid && addressid!=''){
                            address_id = addressid;
                        }
                        var addressinfo;
                        var consigneename;
                        var consigneeaddress;
                        if(consignee_name){
                            consigneename =consignee_name;
                        }else{
                            consigneename = a.result.consignee;
                        }
                        if(consignee_address){
                            consigneeaddress = consignee_address;
                        }else{
                            consigneeaddress = a.result.province+a.result.city+a.result.district+a.result.address;
                        }
                        if(market_number && market_id){
                            if(a.result != ''){
                                addressinfo = '<a href="address.html?market_id='+market_id+'&market_number='+market_number+'"><div><div class="link"><div><i class="iconfont">&#xe630;</i><span>收货人：</span></div><p>'+consigneename+'</p></div><div class="link"><div><i class="iconfont">&#xe63e;</i><span>收货地址：</span></div><p>'+consigneeaddress+'</p></div></div></a>';
                            }else{
                                addressinfo = '<a href="address.html?market_id='+market_id+'&market_number='+market_number+'" class="wu_address"><i class="iconfont">&#xe63e;</i><p>请先添加收货地址~</p></a><a class="right" href="address.html"><img src="img/xia.png"></a>';
                            }
                            $('.order_address_top').html(addressinfo);
                            $('.order_info1').hide();
                            pdataurl = api+'?uid='+uid+'&market_id='+market_id+'&market_number='+market_number+'&address_id='+address_id;
                            pdata = {
                                key:key,
                                module:'order',
                                method:'order.order_page',
                                request_mode:'post',
                                sign:sign,
                                timestamp:timestamp
                            };
                            $.ajax({
                                type: 'post',
                                url: pdataurl,
                                async:false,
                                data:pdata,
                                dataType: 'json',
                                success: function (r) {
                                    console.log(r);
                                    if(r.status =='success') {
                                        $('.order_info .order_top .title img').attr('src',r.result.shop_avatar);
                                        if(r.result.shop_qrcode==''){
                                            $('.seller_contact .seller_contact_bot .seller_contact_ewm').hide();
                                        }
                                        $('.order_info .order_top .title h1').html(r.result.shop_name);
                                        $('.order_info .order_con .book img').attr('src',r.result.market_image);
                                        $('.order_info .order_con .book .title h1').html(r.result.market_name);
                                        $('.order_info .order_con .book .title h2 b').html(r.result.market_price);
                                        $('.order_info .order_con .book .title h2 em').html(r.result.market_number);
                                        $('.seller_contact .seller_contact_bot a').eq(0).find('b').html(r.result.shop_mobile);
                                        var tel = 'tel://'+r.result.shop_mobile;
                                        $('.seller_contact .seller_contact_bot a').eq(0).attr('href',tel);
                                        $('.seller_contact .seller_contact_bot a').eq(1).find('b').html(r.result.shop_brief);
                                        $('.seller_contact .seller_contact_bot a').eq(2).find('b').html(r.result.shop_province+r.result.shop_city+r.result.shop_address);
                                        $('.order_info .order .order_bot h1').eq(0).find('b').html(r.result.market_number);
                                        var total_price = r.result.market_number * r.result.market_price;
                                        total_price = returnFloat(total_price);
                                        $('.order_pay h2 b').html(r.result.market_number);
                                        var fee = 0.00;
                                        if(parseInt(total_price*100)>= parseInt(r.result.fee.max_fee*100)){
                                            fee = 0.00;
                                        }else{
                                            fee = r.result.fee.base_fee
                                        }
                                        fee = returnFloat(fee);
                                        var total_prices = (total_price*100+fee*100)/100;
                                        total_prices = returnFloat(total_prices);
                                        $('.order_info .order .order_bot h1').eq(0).find('em').text(total_prices);
                                        $('.order_pay h1 font').html(total_prices);
                                        $('.order_info .order_bot h1').eq(1).find('b').text(fee);
                                        $('.order_pay .pay_top h2 em').text(fee);
                                        if(r.result.referee !=''){
                                            $('.order_info .tjr b').text(r.result.referee.name)
                                        }
                                    }else{
                                        alert(r.msg);
                                    }
                                },
                                error: function(XMLHttpRequest1, textStatus1, errorThrown1) {
                                    // alert(XMLHttpRequest.status);
                                    // alert(XMLHttpRequest.readyState);
                                    // alert(textStatus);
                                }
                            });
                        }else if(cart_id){
                            if(a.result != ''){
                                addressinfo = '<a href="address.html?cart_ids='+cart_id+'"><div><div class="link"><div><i class="iconfont">&#xe630;</i><span>收货人：</span></div><p>'+consigneename+'</p></div><div class="link"><div><i class="iconfont">&#xe63e;</i><span>收货地址：</span></div><p>'+consigneeaddress+'</p></div></div></a>';
                            }else{
                                addressinfo = '<a href="address.html?cart_ids='+cart_id+'" class="wu_address"><i class="iconfont">&#xe63e;</i><p>请先添加收货地址~</p></a><a class="right" href="address.html"><img src="img/xia.png"></a>';
                            }
                            $('.order_address_top').html(addressinfo);
                            $('.order_info').hide();
                            pdataurl = api+'?uid='+uid+'&cart_id='+cart_id+'&address_id='+address_id;
                            pdata = {
                                key:key,
                                module:'order',
                                method:'cart.showById',
                                request_mode:'post',
                                sign:sign,
                                timestamp:timestamp
                            };
                            $.ajax({
                                type: 'post',
                                url: pdataurl,
                                async:false,
                                data:pdata,
                                dataType: 'json',
                                success: function (r) {
                                    console.log(r);
                                    if(r.status =='success') {
                                        var orderinfo = r.result;
                                        var html = template('tpl_translation_order_list', orderinfo);
                                        document.getElementById('translation_order_list').innerHTML = html;
                                        $('.contact_seller1').on('click',function () {
                                            var shop_mobile = $(this).find('span').eq(0).html();
                                            var shop_brief = $(this).find('span').eq(1).html();
                                            var adressinfo = $(this).find('span').eq(2).html();
                                            $('.seller_contact .seller_contact_bot a').eq(0).find('b').text(shop_mobile);
                                            var tel = 'tel://'+shop_mobile;
                                            $('.seller_contact .seller_contact_bot a').eq(0).attr('href',tel);
                                            $('.seller_contact .seller_contact_bot a').eq(1).find('b').text(shop_brief);
                                            $('.seller_contact .seller_contact_bot a').eq(2).find('b').text(adressinfo);
                                            $(".seller_contact_top").css('padding-bottom','20px');
                                            $(".seller_contact_top img").hide();
                                            $(".seller_contact_ewm img").hide();
                                            $(".seller_contact").show();
                                            // 吉祥物突出来的高度
                                            var sellerHeight = $(".seller_contact_top img").height();
                                            $(".seller_contact_top img").css("margin-top",-sellerHeight/2 - 10);
                                            // 白色部分  的高度要加上吉祥物突出来的高度
                                            $(".seller_contact_con_con").css("margin-top",sellerHeight/2 +10);
                                        });
                                        var allprice = 0; //总价
                                        var allnum = 0; //所有商品数量
                                        var allfee = 0; //所有商品数量
                                        $('.shoporder').each(function () {
                                            var oneprice = 0;
                                            var onenum = 0;
                                            var onefee = 0;
                                            $(this).find('.order_list1').each(function () {
                                                var oprice = 0; //店铺总价
                                                var onum = 0;
                                                var fee = 0;
                                                $(this).find('.order_con').each(function () {
                                                    var num = parseInt($(this).find("h2 em").text()); //得到商品的数量
                                                    var price = parseFloat($(this).find("h2 b").text()); //得到商品的单价
                                                    var total = price * num; //计算单个商品的总价
                                                    oprice += total; //计算该店铺的总价
                                                    onum += num;   //计算店铺商品的总数量
                                                });
                                                var max_fee = $(this).find('.order_bot h1').eq(1).find('strong').text();
                                                var base_fee = $(this).find('.order_bot h1').eq(1).find('i').text();
                                                if(parseInt(oprice*100)>=parseInt(max_fee*100)){
                                                    fee = 0.00;
                                                }else{
                                                    fee = base_fee;
                                                }
                                                fee = returnFloat(fee);
                                                $(this).find('.order_bot h1').eq(1).find('font').text(fee);
                                                $(this).find('.order_bot h1 b').text(onum);

                                                var oprices = (oprice*100+fee*100)/100;
                                                oprices = returnFloat(oprices);
                                                $(this).find('.order_bot h1 em').text(oprices);
                                                oneprice = parseFloat($(this).find(".order_bot h1 em").text()); //得到每个店铺的总价
                                                onenum = parseInt($(this).find(".order_bot h1 b").text()); //得到每个店铺商品数量
                                                onefee = parseFloat($(this).find(".order_bot h1 font").text());
                                                allprice += oneprice; //计算所有店铺的总价
                                                allnum += onenum;//计算所有商品数量
                                                allfee += onefee;
                                            });
                                        });
                                        allprice = returnFloat(allprice);
                                        allfee = returnFloat(allfee);
                                        $('.order_pay .pay_top h2 b').text(allnum);
                                        $('.order_pay .pay_top h2 em').text(allfee);
                                        $('.order_pay .pay_top h1 font').text(allprice);
                                    }else{
                                        alert(r.msg);
                                    }
                                },
                                error: function(XMLHttpRequest1, textStatus1, errorThrown1) {
                                    // alert(XMLHttpRequest.status);
                                    // alert(XMLHttpRequest.readyState);
                                    // alert(textStatus);
                                }
                            });
                        }
                    }
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
        $('.seller_contact6 .seller_contact_button a').eq(0).on('click',function () {
            if(market_number && market_id){
                window.location.href='add_address.html?nmarket_id='+market_id+'&nmarket_number='+market_number;
            }else if(cart_id){
                window.location.href='add_address.html?ncart_ids='+cart_id;
            }
        });
        $('.seller_contact6 .seller_contact_button a').eq(1).on('click',function () {
            if(market_number && market_id){
                window.location.href='product_details.html?pid='+market_id;
            }else if(cart_id){
                window.location.href='shopping.html';
            }
        });
        $('.order_pay .pay_bot a').eq(1).on('click',function () {
            if(market_number && market_id) {
                $.ajax({
                    type: 'post',
                    url: api + '?uid=' + uid + '&market_id=' + market_id + '&market_number=' + market_number + '&address_id=' + address_id,
                    async: true,
                    data: {
                        key: key,
                        module: 'order',
                        method: 'order.order',
                        request_mode: 'post',
                        sign: sign,
                        timestamp: timestamp
                    },
                    dataType: 'json',
                    success: function (a) {
                        //console.log(a);
                        if (a.status == 'success') {
                            var order_id = a.result.order_id;
                            var total = $('.order_pay .pay_top h1').find('font').text();
                            $.ajax({
                                type: 'post',
                                url: api,
                                async: true,
                                data: {
                                    key: key,
                                    module: 'order',
                                    method: 'order.store_charge',
                                    order_id: order_id,
                                    total: total,
                                    request_mode: 'post',
                                    sign: sign,
                                    timestamp: timestamp,
                                    uid: uid,
                                    user_type:'2'
                                },
                                dataType: 'json',
                                success: function (b) {
                                    console.log(b);
                                    if (b.status == 'success') {
                                        var out_trade_no = b.result.charge_no;
                                        var total_fee = total*100;
                                        var body = '1111';
                                        $.ajax({
                                            type: 'get',
                                            async: true,
                                            url: 'http://librarypay.zhongmeiyixue.com/wechat/mp?out_trade_no='+out_trade_no+'&body='+body+'&total_fee='+total_fee+'&openid='+openid,
                                            dataType: 'json',
                                            success: function (c) {
                                                console.log(c);
                                                var appId = c.appId;
                                                var timestamp = parseInt(c.timeStamp);
                                                var nonceStr = c.nonceStr;
                                                var paySign = c.paySign;
                                                var package = c.package;
                                                var signType = c.signType;
                                                wx.config({
                                                    debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                                                    appId: appId, // 必填，公众号的唯一标识
                                                    timestamp: timestamp, // 必填，生成签名的时间戳
                                                    nonceStr: nonceStr, // 必填，生成签名的随机串
                                                    jsApiList: ['chooseWXPay'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                                                });
                                                wx.ready(function(){
                                                    wx.chooseWXPay({
                                                        timestamp:timestamp,
                                                        nonceStr:nonceStr,
                                                        package : package,
                                                        signType :signType,
                                                        paySign :paySign,
                                                        success: function (d) {
                                                            window.location.href='order.html';
                                                        }
                                                    });
                                                });
                                            },
                                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                                // alert(XMLHttpRequest.status);
                                                // alert(XMLHttpRequest.readyState);
                                                // alert(textStatus);
                                            }
                                        });
                                    }else{
                                        alert(b.msg)
                                    }
                                },
                                error: function (XMLHttpRequest, textStatus, errorThrown) {
                                    // alert(XMLHttpRequest.status);
                                    // alert(XMLHttpRequest.readyState);
                                    // alert(textStatus);
                                }
                            });
                        }else{
                            alert(a.msg);
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }
                });
            }else if(cart_id){
                var remarks = [];
                $('.shoporder').each(function () {
                    var remark = '';
                   $(this).find('.order_list1').each(function () {
                      remark = $(this).find('.liuyan').find('textarea').val();
                      remark = remark.replace(/`/g, "'");
                       remarks.push(remark);
                   });
                });
                var remarka = remarks.join('`');
                $.ajax({
                    type: 'post',
                    url: api + '?uid='+uid+'&cart_id='+cart_id+'&address_id='+address_id+'&remark='+remarka,
                    async: true,
                    data: {
                        key: key,
                        module: 'order',
                        method: 'order.cart_order',
                        request_mode: 'post',
                        sign: sign,
                        timestamp: timestamp
                    },
                    dataType: 'json',
                    success: function (a) {
                        //console.log(a);
                        if (a.status == 'success') {
                            var order_id = a.result.order_id;
                            var total = a.result.total;
                            $.ajax({
                                type: 'post',
                                url: api,
                                async: true,
                                data: {
                                    key: key,
                                    module: 'order',
                                    method: 'order.store_charge',
                                    order_id: order_id,
                                    total: total,
                                    request_mode: 'post',
                                    sign: sign,
                                    timestamp: timestamp,
                                    uid: uid
                                },
                                dataType: 'json',
                                success: function (b) {
                                    console.log(b);
                                    if (b.status == 'success') {
                                        var out_trade_no = b.result.charge_no;
                                        var total_fee = total*100;
                                        var body = '1111';
                                        $.ajax({
                                            type: 'get',
                                            async: true,
                                            url: 'http://librarypay.zhongmeiyixue.com/wechat/mp?out_trade_no='+out_trade_no+'&body='+body+'&total_fee='+total_fee+'&openid='+openid,
                                            dataType: 'json',
                                            success: function (c) {
                                                console.log(c);
                                                var appId = c.appId;
                                                var timestamp = parseInt(c.timeStamp);
                                                var nonceStr = c.nonceStr;
                                                var paySign = c.paySign;
                                                var package = c.package;
                                                var signType = c.signType;
                                                wx.config({
                                                    debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                                                    appId: appId, // 必填，公众号的唯一标识
                                                    timestamp: timestamp, // 必填，生成签名的时间戳
                                                    nonceStr: nonceStr, // 必填，生成签名的随机串
                                                    jsApiList: ['chooseWXPay'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                                                });
                                                wx.ready(function(){
                                                    wx.chooseWXPay({
                                                        timestamp:timestamp,
                                                        nonceStr:nonceStr,
                                                        package : package,
                                                        signType :signType,
                                                        paySign :paySign,
                                                        success: function (d) {
                                                            window.location.reload();
                                                        }
                                                    });
                                                });
                                            },
                                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                                // alert(XMLHttpRequest.status);
                                                // alert(XMLHttpRequest.readyState);
                                                // alert(textStatus);
                                            }
                                        });
                                    }else{
                                        alert(b.msg)
                                    }
                                },
                                error: function (XMLHttpRequest, textStatus, errorThrown) {
                                    // alert(XMLHttpRequest.status);
                                    // alert(XMLHttpRequest.readyState);
                                    // alert(textStatus);
                                }
                            });
                        }else{
                            alert(a.msg);
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }
                });
            }
        });
    })
});