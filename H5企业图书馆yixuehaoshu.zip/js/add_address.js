requirejs(['common'],function(c){
    requirejs(['jquery','validata','jsaddress','style'],function ($,validata,jsaddress) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var modify_address_id = validata.getQueryString('address_id');
        var market_number = validata.getQueryString('market_number');
        var market_id = validata.getQueryString('market_id');
        var cart_id = validata.getQueryString('cart_ids');
        var ncart_ids = validata.getQueryString('ncart_ids');
        var nmarket_number = validata.getQueryString('nmarket_number');
        var nmarket_id = validata.getQueryString('nmarket_id');
        if(cart_id){
            $('.fill_button').find('a').eq(0).attr('href','address.html?cart_ids='+cart_id);
        }else if(ncart_ids){
            $('.fill_button').find('a').eq(0).attr('href','shopping.html');
        }else if(market_number && market_id){
            $('.fill_button').find('a').eq(0).attr('href','address.html?market_id='+market_id+'&market_number='+market_number);
        }else if(nmarket_number && nmarket_id){
            $('.fill_button').find('a').eq(0).attr('href','product_details.html?pid='+nmarket_id);
        }else{
            $('.fill_button').find('a').eq(0).attr('href','address.html');
        }
        if(modify_address_id){
            var consignee = sessionStorage.getItem('consignee');
            var mobile = sessionStorage.getItem('mobile');
            var address = sessionStorage.getItem('address');
            var is_default = sessionStorage.getItem('is_default');
            $('.consignee').val(consignee);
            $('.mobile').val(mobile);
            $('.fill_in').find('textarea').val(address);
            if(is_default == 1){
                $('#male').attr('checked','checked')
            }
        }
        select1();
        $('.province').bind("change", select2);
        $('.city').bind("change", select3);
        function select1() {
            $.ajax({
                type: "post",
                url: api,
                data:{
                    module:'member',
                    method:'address.get_province',
                    request_mode:'post',
                    key:key,
                    sign:sign,
                    timestamp:timestamp
                },
                dataType: 'json',
                success: function (r) {
                    if (r.status == 'success') {
                        var province_options = '<option value="">选择省</option>';
                        for(var i=0;i<r.result.length;i++){
                            province_options+='<option value="'+r.result[i].id+'">'+r.result[i].district_name+'</option>'
                        }
                        $('.province').append(province_options);
                        select2();
                    }
                }
            })
        }
        function select2() {
            $(".city").html("");
            $(".district").html("");
            var pid = $(".province option:checked").attr("value");
            if(pid !=''){
                $.ajax({
                    type: "post",
                    url:  api+'?pid='+pid,
                    data:{
                        module:'member',
                        method:'address.get_city',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    },
                    success: function (r) {
                        if (r.status == 'success') {
                            var city_options = '<option value="">选择市</option>';
                            for(var i=0;i<r.result.length;i++){
                                city_options+='<option value="'+r.result[i].id+'">'+r.result[i].district_name+'</option>'
                            }
                            $('.city').append(city_options);
                            select3();
                        }
                    }
                })
            }
        }
        function select3() {
            $(".district").html("");
            var cid = $(".city option:checked").attr("value");
            if(cid !=''){
                $.ajax({
                    type: "post",
                    url: api+'?pid='+cid,
                    data:{
                        module:'member',
                        method:'address.get_district',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    },
                    success: function (r) {
                        if (r.status == 'success') {
                            var district_options = '<option value="">选择地区</option>';
                            for(var i=0;i<r.result.length;i++){
                                district_options+='<option value="'+r.result[i].id+'">'+r.result[i].district_name+'</option>'
                            }
                            $('.district').append(district_options);
                        }
                    }
                })
            }
        }
        var address_data;
        $('.fill_button a').eq(1).on('click',function () {
            var address = $('.fill_in textarea').val();
            var city = $(".city option:checked").text();
            var district = $(".district option:checked").text();
            var province = $(".province option:checked").text();
            var city_id = $(".city option:checked").attr("value");
            var district_id = $(".district option:checked").attr("value");
            var province_id = $(".province option:checked").attr("value");
            var consignee = $('.consignee').val();
            var mobile = $('.mobile').val();
            var is_default;
            var isdefault = $("#male").get(0).checked;
            if(isdefault){
                is_default = 1;
            }else{
                is_default = 0;
            }
            if(consignee == ''){
                alert('收货人姓名不能为空');
                return false;
            }else if(mobile == ''){
                alert('收货人电话不能为空');
                return false;
            }else if(province_id == ''){
                alert('请选择省');
                return false;
            }else if(city_id == ''){
                alert('请选择市');
                return false;
            }else if(district_id == ''){
                alert('请选择地区');
                return false;
            }else if(address == ''){
                alert('详细地址不能为空');
                return false;
            }
            var reg=/[^0-9]/g;
            var len=mobile.length
            if (len!=11) {
                alert("您输入的手机号码位数不正确！");
                return false;
            } else if (reg.test(mobile)) {
                alert("手机号码必须是数字！");
                return false;
            }
            if(modify_address_id){
                address_data = {
                    address_id:modify_address_id,
                    address:address,
                    city:city,
                    city_id:city_id,
                    district:district,
                    district_id:district_id,
                    province:province,
                    province_id:province_id,
                    consignee:consignee,
                    is_default:is_default,
                    mobile:mobile,
                    module:'member',
                    method:'address.update',
                    request_mode:'post',
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    uid:uid
                }
            }else{
                address_data = {
                    address:address,
                    city:city,
                    city_id:city_id,
                    district:district,
                    district_id:district_id,
                    province:province,
                    province_id:province_id,
                    consignee:consignee,
                    is_default:is_default,
                    mobile:mobile,
                    module:'member',
                    method:'address.store',
                    request_mode:'post',
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    uid:uid
                }
            }
            $.ajax({
                type: 'post',
                url: api,
                data:address_data,
                dataType: 'json',
                success: function (a) {
                    //console.log(a);
                    if(a.status =='success') {
                        if(cart_id){
                            window.location.href='address.html?cart_ids='+cart_id;
                        }else if(ncart_ids){
                            window.location.href='order_generate.html?cart_ids='+ncart_ids;
                        }else if(market_number && market_id){
                            window.location.href='address.html?market_id='+market_id+'&market_number='+market_number;
                        }else if(nmarket_number && nmarket_id){
                            window.location.href='order_generate.html?market_id='+nmarket_id+'&market_number='+nmarket_number;
                        }else{
                            window.location.href='address.html';
                        }
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                }
            });
        })
    })
})