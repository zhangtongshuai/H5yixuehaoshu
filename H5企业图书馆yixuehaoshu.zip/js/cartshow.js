requirejs(['common'],function(c){
    requirejs(['jquery','validata'],function ($,validata) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        //购物车红点
        $.ajax({
            type: 'get',
            url: api,
            data:{
                module:'order',
                method:'cart.show',
                request_mode:'get',
                key:key,
                sign:sign,
                timestamp:timestamp,
                uid:uid
            },
            dataType: 'json',
            success: function (r) {
                if(r.status =='success') {
                    if(r.result == null){
                        $('.nav a').find('b').hide();
                        $('.subnav a').find('b').hide();
                    }else{
                        $('.nav a').find('b').show();
                        $('.subnav a').find('b').show();
                    }
                }
            }
        });
    })
});