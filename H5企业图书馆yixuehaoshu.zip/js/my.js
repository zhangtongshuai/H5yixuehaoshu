requirejs(['common'],function(c){
    requirejs(['jquery','validata','cartshow','style'],function ($,validata) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var openid = validata.isOpenid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        $.ajax({
            type: 'post',
            url: api+'?uid='+uid,
            data:{
                module:'member',
                method:'user.show',
                request_mode:'post',
                key:key,
                sign:sign,
                timestamp:timestamp
            },
            dataType: 'json',
            success: function (a) {
                console.log(a);
                if(a.status =='success') {
                    $('.photo .head_photo').attr('src',a.result.avatar);
                    if(a.result.sex == 1){
                        $('.photo span img').attr('src','img/man.png');
                    }else{
                        $('.photo span img').attr('src','img/woman.png');
                    }
                    $('.title h1').eq(0).html(a.result.name);
                    $('.title h1').eq(1).html(a.result.uid)
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                // alert(XMLHttpRequest.status);
                // alert(XMLHttpRequest.readyState);
                // alert(textStatus);
            }
        });
    })
})